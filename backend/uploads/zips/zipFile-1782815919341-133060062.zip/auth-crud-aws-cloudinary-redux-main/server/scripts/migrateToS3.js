import mongoose from 'mongoose';
import axios from 'axios';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import Property from '../src/models/Property.js';
import dotenv from 'dotenv';

dotenv.config();

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
  }
});

async function migrateImages() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('📦 Connected to MongoDB');

    const properties = await Property.find({ 'images.url': /cloudinary/ });
    console.log(`📸 Found ${properties.length} properties with Cloudinary images`);

    for (const property of properties) {
      console.log(`\n🔄 Processing property: ${property._id}`);
      
      const newImages = [];
      
      for (const image of property.images) {
        try {
          // Download from Cloudinary
          const response = await axios.get(image.url, { responseType: 'arraybuffer' });
          
          // Generate S3 key
          const key = `properties/${Date.now()}-${Math.random().toString(36)}.jpg`;
          
          // Upload to S3
          await s3Client.send(new PutObjectCommand({
            Bucket: process.env.AWS_BUCKET_NAME,
            Key: key,
            Body: response.data,
            ContentType: 'image/jpeg'
          }));
          
          // S3 URL
          const s3Url = `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
          
          newImages.push({
            url: s3Url,
            key: key,
            filename: image.filename || 'property-image.jpg'
          });
          
          console.log(`  ✅ Migrated: ${image.url} → ${s3Url}`);
        } catch (error) {
          console.error(`  ❌ Failed: ${image.url}`, error.message);
        }
      }
      
      // Update property
      property.images = newImages;
      await property.save();
      console.log(`  ✅ Property ${property._id} updated`);
    }

    console.log('\n🎉 Migration completed!');
    process.exit(0);
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

migrateImages();