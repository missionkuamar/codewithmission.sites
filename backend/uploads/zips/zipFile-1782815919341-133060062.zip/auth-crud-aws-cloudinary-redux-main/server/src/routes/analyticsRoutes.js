import express from 'express';
import {
  getAnalyticsOverview,
  getViewsAnalytics,
  getPropertyPerformance,
  getLeadAnalytics,
  getMarketComparison,
  trackPropertyView
} from '../controllers/analyticsController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// Public route for tracking views
router.post('/track-view/:propertyId', trackPropertyView);

// Protected routes (seller only)
router.get('/overview', protect, authorize('seller'), getAnalyticsOverview);
router.get('/views', protect, authorize('seller'), getViewsAnalytics);
router.get('/properties', protect, authorize('seller'), getPropertyPerformance);
router.get('/leads', protect, authorize('seller'), getLeadAnalytics);
router.get('/comparison', protect, authorize('seller'), getMarketComparison);

export default router;