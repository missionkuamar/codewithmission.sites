import express from 'express';
import { 
  createProperty,
  getProperties,
  getPropertyById,
  getMyProperties,
  updateProperty,
  deleteProperty,
  deletePropertyImage
} from '../controllers/propertyController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';
import { uploadMultiple } from '../middleware/uploadMiddleware.js';

const router = express.Router();

// Public routes
router.get('/', getProperties);
router.get('/:id', getPropertyById);

// Protected routes (Seller only)
router.post('/', protect, authorize('seller', 'admin'), uploadMultiple, createProperty);
router.get('/seller/me', protect, authorize('seller'), getMyProperties);
router.put('/:id', protect, authorize('seller', 'admin'), uploadMultiple, updateProperty);
router.delete('/:id', protect, authorize('seller', 'admin'), deleteProperty);
router.delete('/:id/images/:imageId', protect, authorize('seller', 'admin'), deletePropertyImage);

export default router;