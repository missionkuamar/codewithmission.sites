import express from 'express';
import {
  getUsers,
  updateUserStatus,
  deleteUser,
  getPendingProperties,
  approveProperty,
  getDashboardStats
} from '../controllers/adminController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes are protected and admin-only
router.use(protect, authorize('admin'));

// Dashboard stats
router.get('/stats', getDashboardStats);

// User management
router.get('/users', getUsers);
router.put('/users/:id/status', updateUserStatus);
router.delete('/users/:id', deleteUser);

// Property approval
router.get('/properties/pending', getPendingProperties);
router.put('/properties/:id/approve', approveProperty);

export default router;