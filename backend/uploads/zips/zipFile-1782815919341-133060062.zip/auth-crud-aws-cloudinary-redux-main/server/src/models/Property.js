import mongoose from 'mongoose';

const propertySchema = new mongoose.Schema({
  sellerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    required: [true, 'Title is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Description is required']
  },
  price: {
    type: Number,
    required: [true, 'Price is required']
  },
  propertyType: {
    type: String,
    enum: ['flat', 'villa', 'plot', 'commercial', 'independent house'],
    required: [true, 'Property type is required']
  },
  status: {
    type: String,
    enum: ['sale', 'rent'],
    required: [true, 'Status is required']
  },
  bedrooms: {
    type: Number,
    required: [true, 'Bedrooms count is required']
  },
  bathrooms: {
    type: Number,
    required: [true, 'Bathrooms count is required']
  },
  area: {
    type: Number,
    required: [true, 'Area is required']
  },
  location: {
    address: String,
    city: {
      type: String,
      required: [true, 'City is required']
    },
    state: String,
    pincode: String,
    landmark: String
  },
  amenities: [String],
  images: [{
    url: String,
    publicId: String
  }],
  featured: {
    type: Boolean,
    default: false
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  views: {
    type: Number,
    default: 0
  },
  contactInfo: {
    name: String,
    phone: String,
    email: String
  }
}, {
  timestamps: true
});

// Index for search
propertySchema.index({ 
  'location.city': 'text', 
  title: 'text', 
  description: 'text' 
});

const Property = mongoose.model('Property', propertySchema);
export default Property;