import Property from '../models/Property.js';
import Inquiry from '../models/Inquiry.js';

// @desc    Get seller analytics overview
// @route   GET /api/analytics/overview
// @access  Private/Seller
export const getAnalyticsOverview = async (req, res) => {
  try {
    const sellerId = req.user._id;

    // Get all seller properties
    const properties = await Property.find({ sellerId });

    // Basic stats
    const totalProperties = properties.length;
    const totalViews = properties.reduce((sum, p) => sum + (p.views || 0), 0);
    const featuredCount = properties.filter(p => p.featured).length;
    const pendingApprovals = properties.filter(p => !p.isApproved).length;

    // Get inquiries for seller's properties
    const propertyIds = properties.map(p => p._id);
    const inquiries = await Inquiry.find({ 
      propertyId: { $in: propertyIds } 
    });
    
    const totalInquiries = inquiries.length;
    const uniqueInquirers = new Set(inquiries.map(i => i.email)).size;

    // Average views per property
    const avgViews = totalProperties ? (totalViews / totalProperties).toFixed(0) : 0;

    // Most viewed property
    const mostViewed = properties.sort((a, b) => (b.views || 0) - (a.views || 0))[0];

    res.json({
      success: true,
      analytics: {
        overview: {
          totalProperties,
          totalViews,
          totalInquiries,
          uniqueInquirers,
          avgViews,
          featuredCount,
          pendingApprovals,
          mostViewed: mostViewed ? {
            id: mostViewed._id,
            title: mostViewed.title,
            views: mostViewed.views || 0
          } : null
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get views analytics (daily/weekly/monthly)
// @route   GET /api/analytics/views
// @access  Private/Seller
export const getViewsAnalytics = async (req, res) => {
  try {
    const { period = 'monthly' } = req.query;
    const sellerId = req.user._id;

    const properties = await Property.find({ sellerId });
    const propertyIds = properties.map(p => p._id);

    let groupFormat;
    if (period === 'daily') {
      groupFormat = '%Y-%m-%d';
    } else if (period === 'weekly') {
      groupFormat = '%Y-%W';
    } else {
      groupFormat = '%Y-%m';
    }

    // Note: This assumes you have a View model tracking each view
    // If not, we'll use property.views which is cumulative
    const viewsData = await Property.aggregate([
      { $match: { _id: { $in: propertyIds } } },
      { $unwind: { path: '$viewHistory', preserveNullAndEmptyArrays: true } },
      {
        $group: {
          _id: {
            $dateToString: { format: groupFormat, date: '$viewHistory.date' }
          },
          views: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json({
      success: true,
      period,
      data: viewsData
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get property performance
// @route   GET /api/analytics/properties
// @access  Private/Seller
export const getPropertyPerformance = async (req, res) => {
  try {
    const sellerId = req.user._id;

    const properties = await Property.find({ sellerId })
      .select('title price views createdAt status propertyType location city featured');

    // Get inquiry counts for each property
    const propertyIds = properties.map(p => p._id);
    const inquiries = await Inquiry.aggregate([
      { $match: { propertyId: { $in: propertyIds } } },
      { $group: { _id: '$propertyId', count: { $sum: 1 } } }
    ]);

    // Create inquiry map
    const inquiryMap = {};
    inquiries.forEach(i => { inquiryMap[i._id] = i.count; });

    // Calculate performance score
    const performanceData = properties.map(p => {
      const views = p.views || 0;
      const inquiries = inquiryMap[p._id] || 0;
      const conversionRate = views ? ((inquiries / views) * 100).toFixed(1) : 0;
      
      // Performance score based on views, inquiries, and age
      const daysSincePosted = Math.ceil((new Date() - new Date(p.createdAt)) / (1000 * 60 * 60 * 24));
      const score = Math.min(100, Math.round(
        (views * 0.3) + (inquiries * 10) + (p.featured ? 20 : 0) - (daysSincePosted * 0.5)
      ));

      return {
        id: p._id,
        title: p.title,
        price: p.price,
        location: `${p.location?.city || ''} ${p.location?.address || ''}`.trim(),
        views,
        inquiries,
        conversionRate,
        featured: p.featured,
        status: p.status,
        daysSincePosted,
        score: Math.max(0, score)
      };
    });

    // Sort by performance score
    performanceData.sort((a, b) => b.score - a.score);

    res.json({
      success: true,
      properties: performanceData
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get lead analytics
// @route   GET /api/analytics/leads
// @access  Private/Seller
export const getLeadAnalytics = async (req, res) => {
  try {
    const sellerId = req.user._id;

    const properties = await Property.find({ sellerId });
    const propertyIds = properties.map(p => p._id);

    const leads = await Inquiry.find({ propertyId: { $in: propertyIds } })
      .populate('propertyId', 'title price')
      .sort({ createdAt: -1 });

    // Lead statistics
    const totalLeads = leads.length;
    const contactedLeads = leads.filter(l => l.contacted).length;
    const convertedLeads = leads.filter(l => l.converted).length;
    const conversionRate = totalLeads ? ((convertedLeads / totalLeads) * 100).toFixed(1) : 0;

    // Leads by property
    const leadsByProperty = {};
    leads.forEach(lead => {
      const propertyTitle = lead.propertyId?.title || 'Unknown';
      if (!leadsByProperty[propertyTitle]) {
        leadsByProperty[propertyTitle] = 0;
      }
      leadsByProperty[propertyTitle]++;
    });

    // Recent leads
    const recentLeads = leads.slice(0, 10).map(l => ({
      id: l._id,
      name: l.name,
      email: l.email,
      phone: l.phone,
      property: l.propertyId?.title,
      date: l.createdAt,
      contacted: l.contacted || false
    }));

    res.json({
      success: true,
      leads: {
        total: totalLeads,
        contacted: contactedLeads,
        converted: convertedLeads,
        conversionRate,
        byProperty: leadsByProperty,
        recent: recentLeads
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get comparison with market
// @route   GET /api/analytics/comparison
// @access  Private/Seller
export const getMarketComparison = async (req, res) => {
  try {
    const sellerId = req.user._id;

    // Get seller's properties
    const sellerProperties = await Property.find({ sellerId });
    const sellerAvgPrice = sellerProperties.length 
      ? sellerProperties.reduce((sum, p) => sum + p.price, 0) / sellerProperties.length 
      : 0;
    const sellerAvgViews = sellerProperties.length 
      ? sellerProperties.reduce((sum, p) => sum + (p.views || 0), 0) / sellerProperties.length 
      : 0;

    // Get market average (all properties in same cities)
    const cities = [...new Set(sellerProperties.map(p => p.location?.city).filter(Boolean))];
    
    const marketProperties = await Property.find({
      'location.city': { $in: cities },
      isApproved: true
    });

    const marketAvgPrice = marketProperties.length
      ? marketProperties.reduce((sum, p) => sum + p.price, 0) / marketProperties.length
      : 0;

    const marketAvgViews = marketProperties.length
      ? marketProperties.reduce((sum, p) => sum + (p.views || 0), 0) / marketProperties.length
      : 0;

    // Calculate position
    const pricePosition = marketAvgPrice 
      ? ((sellerAvgPrice - marketAvgPrice) / marketAvgPrice * 100).toFixed(1)
      : 0;

    const viewsPosition = marketAvgViews
      ? ((sellerAvgViews - marketAvgViews) / marketAvgViews * 100).toFixed(1)
      : 0;

    res.json({
      success: true,
      comparison: {
        price: {
          seller: Math.round(sellerAvgPrice),
          market: Math.round(marketAvgPrice),
          difference: Math.round(sellerAvgPrice - marketAvgPrice),
          percentDiff: pricePosition
        },
        views: {
          seller: Math.round(sellerAvgViews),
          market: Math.round(marketAvgViews),
          difference: Math.round(sellerAvgViews - marketAvgViews),
          percentDiff: viewsPosition
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Track property view
// @route   POST /api/analytics/track-view/:propertyId
// @access  Public
export const trackPropertyView = async (req, res) => {
  try {
    const property = await Property.findById(req.params.propertyId);
    
    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    // Increment views
    property.views = (property.views || 0) + 1;
    
    // Add to view history (if you want detailed tracking)
    if (!property.viewHistory) property.viewHistory = [];
    property.viewHistory.push({
      date: new Date(),
      ip: req.ip || req.connection.remoteAddress
    });

    await property.save();

    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};