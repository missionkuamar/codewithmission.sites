import User from '../models/User.js';
import Property from '../models/Property.js';

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private/Admin
export const getUsers = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', role = '' } = req.query;

    // Build filter
    const filter = {};
    if (role) filter.role = role;
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { phone: { $regex: search, $options: 'i' } }
      ];
    }

    const users = await User.find(filter)
      .select('-password')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await User.countDocuments(filter);

    res.json({
      success: true,
      users,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / parseInt(limit))
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Update user status (block/unblock)
// @route   PUT /api/admin/users/:id/status
// @access  Private/Admin
export const updateUserStatus = async (req, res) => {
  try {
    const { isActive } = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isActive },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      success: true,
      user,
      message: `User ${isActive ? 'activated' : 'blocked'} successfully`
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Delete user
// @route   DELETE /api/admin/users/:id
// @access  Private/Admin
export const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Don't allow deleting yourself
    if (user._id.toString() === req.user._id.toString()) {
      return res.status(400).json({ message: 'Cannot delete your own account' });
    }

    // Delete user's properties first
    await Property.deleteMany({ sellerId: user._id });
    
    // Delete user
    await user.deleteOne();

    res.json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get pending properties for approval
// @route   GET /api/admin/properties/pending
// @access  Private/Admin
export const getPendingProperties = async (req, res) => {
  try {
    const properties = await Property.find({ isApproved: false })
      .populate('sellerId', 'name email phone')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      properties
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Approve or reject property
// @route   PUT /api/admin/properties/:id/approve
// @access  Private/Admin
export const approveProperty = async (req, res) => {
  try {
    const { isApproved, rejectionReason } = req.body;
    
    const property = await Property.findById(req.params.id)
      .populate('sellerId', 'name email');

    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    property.isApproved = isApproved;
    if (!isApproved && rejectionReason) {
      property.rejectionReason = rejectionReason;
    }
    
    await property.save();

    // TODO: Send email notification to seller
    // if (property.sellerId?.email) {
    //   sendApprovalEmail(property.sellerId.email, property.title, isApproved);
    // }

    res.json({
      success: true,
      property,
      message: `Property ${isApproved ? 'approved' : 'rejected'} successfully`
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get dashboard stats
// @route   GET /api/admin/stats
// @access  Private/Admin
export const getDashboardStats = async (req, res) => {
  try {
    const [
      totalUsers,
      totalSellers,
      totalBuyers,
      totalProperties,
      pendingProperties,
      approvedProperties,
      totalViews,
      recentUsers,
      recentProperties,
      propertiesByType,
      propertiesByCity,
      monthlyStats
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ role: 'seller' }),
      User.countDocuments({ role: 'buyer' }),
      Property.countDocuments(),
      Property.countDocuments({ isApproved: false }),
      Property.countDocuments({ isApproved: true }),
      Property.aggregate([{ $group: { _id: null, total: { $sum: '$views' } } }]),
      User.find().select('-password').sort({ createdAt: -1 }).limit(5),
      Property.find()
        .populate('sellerId', 'name')
        .sort({ createdAt: -1 })
        .limit(5),
      Property.aggregate([
        { $group: { _id: '$propertyType', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]),
      Property.aggregate([
        { $group: { _id: '$location.city', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 5 }
      ]),
      Property.aggregate([
        {
          $group: {
            _id: { $dateToString: { format: '%Y-%m', date: '$createdAt' } },
            count: { $sum: 1 }
          }
        },
        { $sort: { _id: -1 } },
        { $limit: 12 }
      ])
    ]);

    res.json({
      success: true,
      stats: {
        users: {
          total: totalUsers,
          sellers: totalSellers,
          buyers: totalBuyers
        },
        properties: {
          total: totalProperties,
          pending: pendingProperties,
          approved: approvedProperties,
          totalViews: totalViews[0]?.total || 0
        },
        charts: {
          propertiesByType,
          propertiesByCity,
          monthlyStats
        },
        recent: {
          users: recentUsers,
          properties: recentProperties
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};