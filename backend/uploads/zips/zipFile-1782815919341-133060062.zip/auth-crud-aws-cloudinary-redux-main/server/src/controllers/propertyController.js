import Property from '../models/Property.js';
import cloudinary from '../config/cloudinary.js';


import { deleteFromS3, getS3Url } from '../config/aws.js';

// @desc    Create new property
// @route   POST /api/properties
// @access  Private (Seller only)
// createProperty function mein yeh log add karo

// cloudinary upload karo
// export const createProperty = async (req, res) => {
//   try {
//     console.log('Creating property with data:', req.body);
//     console.log('Files received:', req.files?.length);

//     const propertyData = {
//       ...req.body,
//       sellerId: req.user._id,
//       images: req.files ? req.files.map(file => ({
//         url: file.path,
//         publicId: file.filename
//       })) : []
//     };

//     // Parse JSON fields
//     if (typeof propertyData.location === 'string') {
//       propertyData.location = JSON.parse(propertyData.location);
//     }
//     if (typeof propertyData.amenities === 'string') {
//       propertyData.amenities = JSON.parse(propertyData.amenities);
//     }

//     const property = await Property.create(propertyData);
    
//     console.log('Property created:', property._id); // Debug log

//     res.status(201).json({
//       success: true,
//       property
//     });
//   } catch (error) {
//     console.error('Error creating property:', error);
//     res.status(500).json({ message: 'Server error', error: error.message });
//   }
// };

// @desc    Get all properties (with filters)
// @route   GET /api/properties
// @access  Public
// @desc    Get all properties (without approval filter for testing)
// @route   GET /api/properties
// @access  Public
export const getProperties = async (req, res) => {
  try {
    console.log('Fetching all properties...'); // Debug log
    
    // ✅ Saari properties lao bina kisi filter ke
    const properties = await Property.find({})
      .populate('sellerId', 'name phone email')
      .sort({ createdAt: -1 });

    console.log('Properties found:', properties.length); // Debug log

    res.json({
      success: true,
      properties,
      total: properties.length,
      page: 1,
      pages: Math.ceil(properties.length / 10)
    });
  } catch (error) {
    console.error('Error fetching properties:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get single property
// @route   GET /api/properties/:id
// @access  Public
export const getPropertyById = async (req, res) => {
  try {
    const property = await Property.findById(req.params.id)
      .populate('sellerId', 'name phone email');

    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    // Increment views
    property.views += 1;
    await property.save();

    res.json({
      success: true,
      property
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get seller's properties
// @route   GET /api/properties/seller/me
// @access  Private (Seller)
export const getMyProperties = async (req, res) => {
  try {
    const properties = await Property.find({ sellerId: req.user._id })
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      properties
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Delete single image from property
// @route   DELETE /api/properties/:id/images/:imageId
// @access  Private (Seller/Admin)
export const deletePropertyImage = async (req, res) => {
  try {
    const property = await Property.findById(req.params.id);

    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    // Check ownership
    if (property.sellerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized' });
    }

    // Find the image
    const image = property.images.id(req.params.imageId);
    if (!image) {
      return res.status(404).json({ message: 'Image not found' });
    }

    console.log('Deleting image:', image); // Debug log

    // ✅ Delete from Cloudinary - publicId check karo
    if (image.publicId) {
      try {
        const result = await cloudinary.uploader.destroy(image.publicId);
        console.log('Cloudinary delete result:', result); // Debug log
        
        if (result.result !== 'ok') {
          console.warn('Cloudinary delete may have failed:', result);
        }
      } catch (cloudinaryError) {
        console.error('Cloudinary delete error:', cloudinaryError);
        // Continue with MongoDB update even if Cloudinary fails
      }
    } else {
      console.warn('No publicId found for image:', image);
    }

    // ✅ Remove from MongoDB array
    property.images.pull(req.params.imageId);
    await property.save();

    res.json({
      success: true,
      message: 'Image deleted successfully'
    });
  } catch (error) {
    console.error('Delete image error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
// @desc    Update property
// @route   PUT /api/properties/:id
// @access  Private (Seller/Admin)


// @desc    Delete property
// @route   DELETE /api/properties/:id
// @access  Private (Seller/Admin)
// @desc    Delete property
// @route   DELETE /api/properties/:id
// @access  Private (Seller/Admin)
/// cloudinary delete
// export const deleteProperty = async (req, res) => {
//   try {
//     const property = await Property.findById(req.params.id);

//     if (!property) {
//       return res.status(404).json({ message: 'Property not found' });
//     }

//     // Check ownership
//     if (property.sellerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
//       return res.status(403).json({ message: 'Not authorized to delete this property' });
//     }

//     console.log('Deleting property with images:', property.images?.length);

//     // ✅ Delete all images from Cloudinary
//     if (property.images && property.images.length > 0) {
//       for (const image of property.images) {
//         if (image.publicId) {
//           try {
//             const result = await cloudinary.uploader.destroy(image.publicId);
//             console.log(`Deleted image ${image.publicId}:`, result);
//           } catch (cloudinaryError) {
//             console.error(`Failed to delete image ${image.publicId}:`, cloudinaryError);
//           }
//         }
//       }
//     }

//     // ✅ Delete from MongoDB
//     await Property.findByIdAndDelete(req.params.id);

//     res.json({
//       success: true,
//       message: 'Property deleted successfully'
//     });
//   } catch (error) {
//     console.error('Delete property error:', error);
//     res.status(500).json({ message: 'Server error', error: error.message });
//   }
// };

// @desc    Delete single image from property
// @route   DELETE /api/properties/:id/images/:imageId
// @access  Private (Seller/Admin)
// @desc    Update property
// @route   PUT /api/properties/:id
// @access  Private (Seller/Admin)
// @desc    Update property
// @route   PUT /api/properties/:id
// @access  Private (Seller/Admin)
// @desc    Update property
// @route   PUT /api/properties/:id
// @access  Private (Seller/Admin)

// cloudinary update
// export const updateProperty = async (req, res) => {
//   try {
//     console.log('========== UPDATE PROPERTY ==========');
//     console.log('Property ID:', req.params.id);
//     console.log('Request Body:', req.body);
//     console.log('Files:', req.files?.length || 0);

//     const property = await Property.findById(req.params.id);
//     if (!property) {
//       return res.status(404).json({ message: 'Property not found' });
//     }

//     // Check ownership
//     if (property.sellerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
//       return res.status(403).json({ message: 'Not authorized' });
//     }

//     // Prepare update data
//     const updateData = { ...req.body };

//     // Parse location
//     if (updateData.location && typeof updateData.location === 'string') {
//       try {
//         updateData.location = JSON.parse(updateData.location);
//       } catch (e) {
//         console.error('Location parse error:', e);
//       }
//     }

//     // Parse amenities
//     if (updateData.amenities && typeof updateData.amenities === 'string') {
//       try {
//         updateData.amenities = JSON.parse(updateData.amenities);
//       } catch (e) {
//         console.error('Amenities parse error:', e);
//       }
//     }

//     // Handle numeric fields
//     if (updateData.price) updateData.price = Number(updateData.price);
//     if (updateData.bedrooms) updateData.bedrooms = Number(updateData.bedrooms);
//     if (updateData.bathrooms) updateData.bathrooms = Number(updateData.bathrooms);
//     if (updateData.area) updateData.area = Number(updateData.area);

//     // ✅ CRITICAL: Handle image deletion
//     let imagesToKeep = [];
    
//     // Parse existingImages from request
//     if (req.body.existingImages) {
//       try {
//         imagesToKeep = JSON.parse(req.body.existingImages);
//         console.log('Images to keep:', imagesToKeep.length);
//       } catch (e) {
//         console.error('Existing images parse error:', e);
//       }
//     }

//     // Get current images from database
//     const currentImages = property.images || [];
//     console.log('Current images in DB:', currentImages.length);

//     // Find images to delete (images that are in DB but not in imagesToKeep)
//     const imagesToDelete = currentImages.filter(dbImage => {
//       return !imagesToKeep.some(keepImage => 
//         keepImage.url === dbImage.url || keepImage._id === dbImage._id.toString()
//       );
//     });

//     console.log('Images to delete:', imagesToDelete.length);

//     // ✅ Delete from Cloudinary
//     if (imagesToDelete.length > 0) {
//       for (const image of imagesToDelete) {
//         if (image.publicId) {
//           try {
//             const result = await cloudinary.uploader.destroy(image.publicId);
//             console.log(`Deleted from Cloudinary: ${image.publicId}`, result);
//           } catch (cloudinaryError) {
//             console.error(`Failed to delete from Cloudinary: ${image.publicId}`, cloudinaryError);
//           }
//         }
//       }
//     }

//     // ✅ Prepare final images array (keep images + new uploads)
//     let finalImages = imagesToKeep.map(img => ({
//       url: img.url,
//       publicId: img.publicId,
//       _id: img._id
//     }));

//     // Add new images from upload
//     if (req.files && req.files.length > 0) {
//       const newImages = req.files.map(file => ({
//         url: file.path,
//         publicId: file.filename
//       }));
//       finalImages = [...finalImages, ...newImages];
//       console.log('New images added:', newImages.length);
//     }

//     updateData.images = finalImages;
//     console.log('Final images after update:', finalImages.length);

//     // Remove undefined fields
//     Object.keys(updateData).forEach(key => 
//       updateData[key] === undefined && delete updateData[key]
//     );

//     console.log('Final update data prepared');

//     // Update property
//     const updatedProperty = await Property.findByIdAndUpdate(
//       req.params.id,
//       { $set: updateData },
//       { new: true, runValidators: true }
//     ).populate('sellerId', 'name phone email');

//     console.log('✅ Property updated successfully:', updatedProperty._id);
//     console.log('=====================================');

//     res.json({
//       success: true,
//       property: updatedProperty
//     });

//   } catch (error) {
//     console.error('❌ Update error:', error);
//     res.status(500).json({ 
//       message: 'Server error', 
//       error: error.message 
//     });
//   }
// };

































































// @desc    Create new property
// @route   POST /api/properties
// @access  Private (Seller only)
export const createProperty = async (req, res) => {
  try {
    console.log('Creating property with S3...');
    
    // ✅ Process uploaded files from S3
    const images = req.files ? req.files.map(file => ({
      url: file.location, // S3 URL
      key: file.key,      // S3 key for deletion
      filename: file.originalname
    })) : [];

    const propertyData = {
      ...req.body,
      sellerId: req.user._id,
      images
    };

    // Parse JSON fields
    if (typeof propertyData.location === 'string') {
      propertyData.location = JSON.parse(propertyData.location);
    }
    if (typeof propertyData.amenities === 'string') {
      propertyData.amenities = JSON.parse(propertyData.amenities);
    }

    const property = await Property.create(propertyData);
    
    console.log('✅ Property created with S3 images:', property._id);

    res.status(201).json({
      success: true,
      property
    });
  } catch (error) {
    console.error('❌ Create error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Delete property
// @route   DELETE /api/properties/:id
// @access  Private (Seller/Admin)
export const deleteProperty = async (req, res) => {
  try {
    const property = await Property.findById(req.params.id);
    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    // Check ownership
    if (property.sellerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized' });
    }

    // ✅ Delete images from S3
    if (property.images && property.images.length > 0) {
      console.log('Deleting images from S3...');
      
      for (const image of property.images) {
        if (image.key) {
          try {
            await deleteFromS3(image.key);
          } catch (s3Error) {
            console.error(`Failed to delete from S3: ${image.key}`, s3Error);
          }
        }
      }
    }

    await property.deleteOne();
    
    res.json({
      success: true,
      message: 'Property deleted successfully'
    });
  } catch (error) {
    console.error('❌ Delete error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Update property
// @route   PUT /api/properties/:id
// @access  Private (Seller/Admin)
export const updateProperty = async (req, res) => {
  try {
    const property = await Property.findById(req.params.id);
    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    // Check ownership
    if (property.sellerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const updateData = { ...req.body };

    // Parse JSON fields
    if (updateData.location && typeof updateData.location === 'string') {
      updateData.location = JSON.parse(updateData.location);
    }
    if (updateData.amenities && typeof updateData.amenities === 'string') {
      updateData.amenities = JSON.parse(updateData.amenities);
    }

    // ✅ Handle existing images
    let imagesToKeep = [];
    if (req.body.existingImages) {
      try {
        imagesToKeep = JSON.parse(req.body.existingImages);
      } catch (e) {
        console.error('Existing images parse error:', e);
      }
    }

    // ✅ Find images to delete (in DB but not in keep list)
    const imagesToDelete = property.images.filter(dbImage => {
      return !imagesToKeep.some(keepImage => 
        keepImage.url === dbImage.url || keepImage.key === dbImage.key
      );
    });

    // ✅ Delete from S3
    for (const image of imagesToDelete) {
      if (image.key) {
        try {
          await deleteFromS3(image.key);
        } catch (error) {
          console.error('S3 delete error:', error);
        }
      }
    }

    // ✅ Add new images from S3
    let finalImages = imagesToKeep;
    if (req.files && req.files.length > 0) {
      const newImages = req.files.map(file => ({
        url: file.location,
        key: file.key,
        filename: file.originalname
      }));
      finalImages = [...finalImages, ...newImages];
    }

    updateData.images = finalImages;

    // Update property
    const updatedProperty = await Property.findByIdAndUpdate(
      req.params.id,
      { $set: updateData },
      { new: true, runValidators: true }
    );

    res.json({
      success: true,
      property: updatedProperty
    });
  } catch (error) {
    console.error('❌ Update error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};