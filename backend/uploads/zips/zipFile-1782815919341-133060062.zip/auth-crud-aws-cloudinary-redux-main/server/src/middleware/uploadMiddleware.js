// import multer from 'multer';
// import { CloudinaryStorage } from 'multer-storage-cloudinary';
// import cloudinary from '../config/cloudinary.js';

// const storage = new CloudinaryStorage({
//   cloudinary: cloudinary,
//   params: {
//     folder: 'real-estate/properties',
//     allowed_formats: ['jpg', 'jpeg', 'png', 'webp'],
//     transformation: [{ width: 1000, height: 750, crop: 'limit' }]
//   }
// });

// const upload = multer({ 
//   storage: storage,
//   limits: {
//     fileSize: 5 * 1024 * 1024 // 5MB limit
//   },
//   fileFilter: (req, file, cb) => {
//     if (file.mimetype.startsWith('image/')) {
//       cb(null, true);
//     } else {
//       cb(new Error('Only image files are allowed!'), false);
//     }
//   }
// });

// export const uploadMultiple = upload.array('images', 10); // Max 10 images
// export const uploadSingle = upload.single('image');



import multer from 'multer';
import { uploadToS3 } from '../config/aws.js';

// ✅ Multiple images upload (max 10)
export const uploadMultiple = uploadToS3.array('images', 10);

// ✅ Single image upload
export const uploadSingle = uploadToS3.single('image');

// ✅ Error handler for multer
export const handleMulterError = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ message: 'File too large. Max 5MB' });
    }
    if (err.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({ message: 'Too many files. Max 10' });
    }
    return res.status(400).json({ message: err.message });
  }
  next(err);
};