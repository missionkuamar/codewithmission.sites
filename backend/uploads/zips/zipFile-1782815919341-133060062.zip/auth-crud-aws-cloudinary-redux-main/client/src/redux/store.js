import { configureStore } from '@reduxjs/toolkit'
import authReducer from './slices/authSlice' 
import propertyReducer from './slices/propertySlice'
// import uiReducer from './slices/uiSlice'
import adminReducer from './slices/adminSlice'; // Add this
import analyticsReducer from './slices/analyticsSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
     properties: propertyReducer,
    // ui: uiReducer,
    admin: adminReducer, // Add this
     analytics: analyticsReducer // Add this
  },
})