import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import propertyService from '../../services/propertyService';

// Async thunks
export const fetchProperties = createAsyncThunk(
  'properties/fetchAll',
  async (params, { rejectWithValue }) => {
    try {
      const response = await propertyService.getProperties(params);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch properties');
    }
  }
);

export const fetchPropertyById = createAsyncThunk(
  'properties/fetchById',
  async (id, { rejectWithValue }) => {
    try {
      const response = await propertyService.getPropertyById(id);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch property');
    }
  }
);

export const fetchMyProperties = createAsyncThunk(
  'properties/fetchMy',
  async (_, { rejectWithValue }) => {
    try {
      const response = await propertyService.getMyProperties();
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch your properties');
    }
  }
);

export const createProperty = createAsyncThunk(
  'properties/create',
  async (formData, { rejectWithValue }) => {
    try {
      const response = await propertyService.createProperty(formData);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to create property');
    }
  }
);

export const updateProperty = createAsyncThunk(
  'properties/update',
  async ({ id, formData }, { rejectWithValue }) => {
    try {
      console.log('Updating property with ID:', id);
      console.log('FormData being sent:', formData);
      
      const response = await propertyService.updateProperty(id, formData);
      console.log('Update response:', response);
      
      return response;
    } catch (error) {
      console.error('Update error in thunk:', error);
      return rejectWithValue(error.message || 'Failed to update property');
    }
  }
);

export const deleteProperty = createAsyncThunk(
  'properties/delete',
  async (id, { rejectWithValue }) => {
    try {
      const response = await propertyService.deleteProperty(id);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to delete property');
    }
  }
);

const initialState = {
  properties: [],
  myProperties: [],
  currentProperty: null,
  total: 0,
  page: 1,
  pages: 1,
  loading: false,
  error: null
};

const propertySlice = createSlice({
  name: 'properties',
  initialState,
  reducers: {
    clearPropertyError: (state) => {
      state.error = null;
    },
    clearCurrentProperty: (state) => {
      state.currentProperty = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch all properties
      .addCase(fetchProperties.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchProperties.fulfilled, (state, action) => {
        state.loading = false;
        state.properties = action.payload.properties;
        state.total = action.payload.total;
        state.page = action.payload.page;
        state.pages = action.payload.pages;
      })
      .addCase(fetchProperties.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch single property
      .addCase(fetchPropertyById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchPropertyById.fulfilled, (state, action) => {
        state.loading = false;
        state.currentProperty = action.payload.property;
      })
      .addCase(fetchPropertyById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch my properties
      .addCase(fetchMyProperties.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchMyProperties.fulfilled, (state, action) => {
        state.loading = false;
        state.myProperties = action.payload.properties;
      })
      .addCase(fetchMyProperties.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Create property
      .addCase(createProperty.pending, (state) => {
        state.loading = true;
      })
      .addCase(createProperty.fulfilled, (state, action) => {
        state.loading = false;
        state.myProperties = [action.payload.property, ...state.myProperties];
        state.properties = [action.payload.property, ...state.properties];
      })
      .addCase(createProperty.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Update property
     // Update property
// Update property
.addCase(updateProperty.fulfilled, (state, action) => {
  console.log('Update fulfilled - new property:', action.payload.property);
  
  const updatedProperty = action.payload.property;
  
  // Update in all properties list
  state.properties = state.properties.map(p => 
    p._id === updatedProperty._id ? updatedProperty : p
  );
  
  // Update in myProperties list
  state.myProperties = state.myProperties.map(p => 
    p._id === updatedProperty._id ? updatedProperty : p
  );
  
  // ✅ CRITICAL: Update current property if it's the one being viewed
  if (state.currentProperty?._id === updatedProperty._id) {
    console.log('Updating current property with new images:', updatedProperty.images.length);
    state.currentProperty = updatedProperty;
  }
  
  state.loading = false;
})
      // Delete property
      .addCase(deleteProperty.fulfilled, (state, action) => {
        const id = action.meta.arg;
        state.properties = state.properties.filter(p => p._id !== id);
        state.myProperties = state.myProperties.filter(p => p._id !== id);
        if (state.currentProperty?._id === id) {
          state.currentProperty = null;
        }
      });
  }
});

export const { clearPropertyError, clearCurrentProperty } = propertySlice.actions;
export default propertySlice.reducer;