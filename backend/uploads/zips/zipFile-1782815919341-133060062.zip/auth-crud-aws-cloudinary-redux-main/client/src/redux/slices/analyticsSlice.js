import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import analyticsService from '../../services/analyticsService';

export const fetchOverview = createAsyncThunk(
  'analytics/fetchOverview',
  async (_, { rejectWithValue }) => {
    try {
      const response = await analyticsService.getOverview();
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch analytics');
    }
  }
);

export const fetchViewsAnalytics = createAsyncThunk(
  'analytics/fetchViews',
  async (period, { rejectWithValue }) => {
    try {
      const response = await analyticsService.getViewsAnalytics(period);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch views');
    }
  }
);

export const fetchPropertyPerformance = createAsyncThunk(
  'analytics/fetchPerformance',
  async (_, { rejectWithValue }) => {
    try {
      const response = await analyticsService.getPropertyPerformance();
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch performance');
    }
  }
);

export const fetchLeadAnalytics = createAsyncThunk(
  'analytics/fetchLeads',
  async (_, { rejectWithValue }) => {
    try {
      const response = await analyticsService.getLeadAnalytics();
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch leads');
    }
  }
);

export const fetchMarketComparison = createAsyncThunk(
  'analytics/fetchComparison',
  async (_, { rejectWithValue }) => {
    try {
      const response = await analyticsService.getMarketComparison();
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch comparison');
    }
  }
);

const initialState = {
  overview: null,
  viewsData: [],
  properties: [],
  leads: null,
  comparison: null,
  period: 'monthly',
  loading: false,
  error: null
};

const analyticsSlice = createSlice({
  name: 'analytics',
  initialState,
  reducers: {
    setPeriod: (state, action) => {
      state.period = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Overview
      .addCase(fetchOverview.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchOverview.fulfilled, (state, action) => {
        state.loading = false;
        state.overview = action.payload.analytics;
      })
      .addCase(fetchOverview.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // Views
      .addCase(fetchViewsAnalytics.fulfilled, (state, action) => {
        state.viewsData = action.payload.data;
        state.period = action.payload.period;
      })

      // Performance
      .addCase(fetchPropertyPerformance.fulfilled, (state, action) => {
        state.properties = action.payload.properties;
      })

      // Leads
      .addCase(fetchLeadAnalytics.fulfilled, (state, action) => {
        state.leads = action.payload.leads;
      })

      // Comparison
      .addCase(fetchMarketComparison.fulfilled, (state, action) => {
        state.comparison = action.payload.comparison;
      });
  }
});

export const { setPeriod, clearError } = analyticsSlice.actions;
export default analyticsSlice.reducer;