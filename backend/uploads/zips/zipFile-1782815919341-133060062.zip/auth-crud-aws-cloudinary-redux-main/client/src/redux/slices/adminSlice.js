import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import adminService from '../../services/adminService';

// Async thunks
export const fetchStats = createAsyncThunk(
  'admin/fetchStats',
  async (_, { rejectWithValue }) => {
    try {
      const response = await adminService.getStats();
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch stats');
    }
  }
);

export const fetchUsers = createAsyncThunk(
  'admin/fetchUsers',
  async (params, { rejectWithValue }) => {
    try {
      const response = await adminService.getUsers(params);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch users');
    }
  }
);

export const updateUserStatus = createAsyncThunk(
  'admin/updateUserStatus',
  async ({ userId, isActive }, { rejectWithValue }) => {
    try {
      const response = await adminService.updateUserStatus(userId, isActive);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to update user');
    }
  }
);

export const deleteUser = createAsyncThunk(
  'admin/deleteUser',
  async (userId, { rejectWithValue }) => {
    try {
      const response = await adminService.deleteUser(userId);
      return { userId, ...response };
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to delete user');
    }
  }
);

export const fetchPendingProperties = createAsyncThunk(
  'admin/fetchPendingProperties',
  async (_, { rejectWithValue }) => {
    try {
      const response = await adminService.getPendingProperties();
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to fetch pending properties');
    }
  }
);

export const approveProperty = createAsyncThunk(
  'admin/approveProperty',
  async ({ propertyId, isApproved, rejectionReason }, { rejectWithValue }) => {
    try {
      const response = await adminService.approveProperty(propertyId, isApproved, rejectionReason);
      return response;
    } catch (error) {
      return rejectWithValue(error.message || 'Failed to approve property');
    }
  }
);

const initialState = {
  stats: null,
  users: [],
  pendingProperties: [],
  totalUsers: 0,
  usersPage: 1,
  usersPages: 1,
  loading: false,
  error: null
};

const adminSlice = createSlice({
  name: 'admin',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Stats
      .addCase(fetchStats.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchStats.fulfilled, (state, action) => {
        state.loading = false;
        state.stats = action.payload.stats;
      })
      .addCase(fetchStats.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // Users
      .addCase(fetchUsers.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.users = action.payload.users;
        state.totalUsers = action.payload.total;
        state.usersPage = action.payload.page;
        state.usersPages = action.payload.pages;
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // Update user status
      .addCase(updateUserStatus.fulfilled, (state, action) => {
        const updatedUser = action.payload.user;
        state.users = state.users.map(u => 
          u._id === updatedUser._id ? updatedUser : u
        );
      })

      // Delete user
      .addCase(deleteUser.fulfilled, (state, action) => {
        state.users = state.users.filter(u => u._id !== action.payload.userId);
      })

      // Pending properties
      .addCase(fetchPendingProperties.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchPendingProperties.fulfilled, (state, action) => {
        state.loading = false;
        state.pendingProperties = action.payload.properties;
      })
      .addCase(fetchPendingProperties.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // Approve property
      .addCase(approveProperty.fulfilled, (state, action) => {
        state.pendingProperties = state.pendingProperties.filter(
          p => p._id !== action.payload.property._id
        );
      });
  }
});

export const { clearError } = adminSlice.actions;
export default adminSlice.reducer;