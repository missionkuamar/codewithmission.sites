import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchInquiries } from '../../redux/slices/inquirySlice';
import { FiMail, FiPhone, FiCalendar, FiMessageCircle, FiEye } from 'react-icons/fi';

const SellerInquiries = () => {
  const dispatch = useDispatch();
  const { inquiries, loading } = useSelector((state) => state.inquiries);
  const [selectedInquiry, setSelectedInquiry] = useState(null);

  useEffect(() => {
    dispatch(fetchInquiries());
  }, [dispatch]);

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-6">Inquiries Received</h2>
      
      <div className="space-y-4">
        {inquiries.map((inquiry) => (
          <div key={inquiry._id} className="border rounded-lg p-4 hover:shadow-md transition">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold">{inquiry.name}</h3>
                <p className="text-sm text-gray-600">For: {inquiry.property?.title}</p>
                <p className="text-sm text-gray-500 mt-2">{inquiry.message}</p>
              </div>
              <div className="flex gap-2">
                <a href={`mailto:${inquiry.email}`} className="p-2 text-blue-600 hover:bg-blue-50 rounded">
                  <FiMail />
                </a>
                <a href={`tel:${inquiry.phone}`} className="p-2 text-green-600 hover:bg-green-50 rounded">
                  <FiPhone />
                </a>
              </div>
            </div>
            <div className="mt-2 text-xs text-gray-400">
              {new Date(inquiry.createdAt).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};