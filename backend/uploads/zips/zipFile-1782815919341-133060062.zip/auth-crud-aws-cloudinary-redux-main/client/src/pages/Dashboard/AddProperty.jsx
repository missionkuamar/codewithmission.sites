import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { createProperty, updateProperty, fetchPropertyById, clearCurrentProperty } from '../../redux/slices/propertySlice';
import { FiUpload, FiX, FiMapPin, FiHome, FiDollarSign, FiGrid } from 'react-icons/fi';
import toast from 'react-hot-toast';

const propertyTypes = [
  'flat', 'villa', 'plot', 'commercial', 'independent house'
];

const cities = [
  'Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Ahmedabad', 'Chennai', 'Kolkata', 'Pune', 'Jaipur', 'Lucknow'
];

const AddProperty = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  const { currentProperty, loading } = useSelector((state) => state.properties);
  const { user } = useSelector((state) => state.auth);

  const [images, setImages] = useState([]);
  const [imagePreviews, setImagePreviews] = useState([]);
  // ✅ IMPORTANT: existingImages state add karo
  const [existingImages, setExistingImages] = useState([]);
  const [amenities, setAmenities] = useState([]);
  const [newAmenity, setNewAmenity] = useState('');

  const { register, handleSubmit, setValue, formState: { errors } } = useForm();

  useEffect(() => {
    if (id) {
      dispatch(fetchPropertyById(id));
    }
    return () => {
      dispatch(clearCurrentProperty());
    };
  }, [id, dispatch]);

  // ✅ Populate form with existing data
  useEffect(() => {
    if (currentProperty && id) {
      console.log('Loading property for edit:', currentProperty);
      
      // Basic fields
      setValue('title', currentProperty.title);
      setValue('description', currentProperty.description);
      setValue('price', currentProperty.price);
      setValue('propertyType', currentProperty.propertyType);
      setValue('status', currentProperty.status);
      setValue('bedrooms', currentProperty.bedrooms);
      setValue('bathrooms', currentProperty.bathrooms);
      setValue('area', currentProperty.area);
      
      // Location fields
      setValue('location.address', currentProperty.location?.address || '');
      setValue('location.city', currentProperty.location?.city || '');
      setValue('location.state', currentProperty.location?.state || '');
      setValue('location.pincode', currentProperty.location?.pincode || '');
      setValue('location.landmark', currentProperty.location?.landmark || '');
      
      // Amenities and images
      setAmenities(currentProperty.amenities || []);
      
      // ✅ IMPORTANT: Set existingImages from currentProperty
      if (currentProperty.images && currentProperty.images.length > 0) {
        setExistingImages(currentProperty.images);
        setImagePreviews(currentProperty.images.map(img => img.url));
        console.log('Existing images loaded:', currentProperty.images);
      }
    }
  }, [currentProperty, id, setValue]);

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    setImages([...images, ...files]);
    
    // Create preview URLs
    const previews = files.map(file => URL.createObjectURL(file));
    setImagePreviews([...imagePreviews, ...previews]);
  };

  const removeImage = (index) => {
    console.log('Removing image at index:', index);
    console.log('Existing images:', existingImages);
    console.log('New images:', images);
    
    // Check if it's an existing image from DB or new upload
    if (index < existingImages.length) {
      // Remove from existing images (these will be deleted on server)
      const newExisting = [...existingImages];
      newExisting.splice(index, 1);
      setExistingImages(newExisting);
      console.log('Updated existing images:', newExisting);
      
      // Also remove from previews
      const newPreviews = [...imagePreviews];
      newPreviews.splice(index, 1);
      setImagePreviews(newPreviews);
    } else {
      // Remove new image (not yet uploaded)
      const newImages = [...images];
      const newIndex = index - existingImages.length;
      newImages.splice(newIndex, 1);
      setImages(newImages);
      
      // Remove preview
      const newPreviews = [...imagePreviews];
      URL.revokeObjectURL(newPreviews[index]);
      newPreviews.splice(index, 1);
      setImagePreviews(newPreviews);
    }
  };

  const addAmenity = () => {
    if (newAmenity.trim() && !amenities.includes(newAmenity.trim())) {
      setAmenities([...amenities, newAmenity.trim()]);
      setNewAmenity('');
    }
  };

  const removeAmenity = (index) => {
    setAmenities(amenities.filter((_, i) => i !== index));
  };

  const onSubmit = async (data) => {
    try {
      console.log('Submitting form data:', data);
      console.log('Existing images after deletion:', existingImages);
      
      const formData = new FormData();
      
      // Append all form fields
      Object.keys(data).forEach(key => {
        if (key === 'location') {
          formData.append('location', JSON.stringify(data.location));
        } else if (data[key] !== undefined && data[key] !== null) {
          formData.append(key, data[key]);
        }
      });
      
      // Append amenities
      formData.append('amenities', JSON.stringify(amenities));
      
      // ✅ CRITICAL: Send the remaining existing images
      if (existingImages.length > 0) {
        const imagesToKeep = existingImages.map(img => ({
          url: img.url,
          publicId: img.publicId,
          _id: img._id
        }));
        formData.append('existingImages', JSON.stringify(imagesToKeep));
        console.log('Keeping these images:', imagesToKeep);
      } else {
        // If no existing images, send empty array
        formData.append('existingImages', JSON.stringify([]));
      }
      
      // Append new images
      images.forEach(image => {
        formData.append('images', image);
      });

      // Log FormData contents
      console.log('FormData entries:');
      for (let pair of formData.entries()) {
        if (pair[0] === 'existingImages') {
          console.log(pair[0], JSON.parse(pair[1]));
        } else {
          console.log(pair[0], pair[1]);
        }
      }

      if (id) {
        const result = await dispatch(updateProperty({ id, formData })).unwrap();
        console.log('Update result:', result);
        toast.success('Property updated successfully!');
      } else {
        const result = await dispatch(createProperty(formData)).unwrap();
        toast.success('Property added successfully!');
      }
      
      navigate('/dashboard');
    } catch (error) {
      console.error('Submit error:', error);
      toast.error(error || 'Failed to save property');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6">
        {id ? 'Edit Property' : 'Add New Property'}
      </h1>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Basic Information */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center">
            <FiHome className="mr-2" /> Basic Information
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Title *
              </label>
              <input
                type="text"
                {...register('title', { required: 'Title is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="e.g., 3 BHK Luxury Apartment"
              />
              {errors.title && (
                <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Price (₹) *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FiDollarSign className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="number"
                  {...register('price', { required: 'Price is required' })}
                  className="w-full pl-10 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                  placeholder="5000000"
                />
              </div>
              {errors.price && (
                <p className="mt-1 text-sm text-red-600">{errors.price.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Property Type *
              </label>
              <select
                {...register('propertyType', { required: 'Property type is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
              >
                <option value="">Select type</option>
                {propertyTypes.map(type => (
                  <option key={type} value={type}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </option>
                ))}
              </select>
              {errors.propertyType && (
                <p className="mt-1 text-sm text-red-600">{errors.propertyType.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status *
              </label>
              <select
                {...register('status', { required: 'Status is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
              >
                <option value="">Select status</option>
                <option value="sale">For Sale</option>
                <option value="rent">For Rent</option>
              </select>
              {errors.status && (
                <p className="mt-1 text-sm text-red-600">{errors.status.message}</p>
              )}
            </div>
          </div>
        </div>

        {/* Location Information */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center">
            <FiMapPin className="mr-2" /> Location Details
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Address *
              </label>
              <input
                type="text"
                {...register('location.address', { required: 'Address is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Street address"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                City *
              </label>
              <select
                {...register('location.city', { required: 'City is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
              >
                <option value="">Select city</option>
                {cities.map(city => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                State
              </label>
              <input
                type="text"
                {...register('location.state')}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="State"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Pincode
              </label>
              <input
                type="text"
                {...register('location.pincode')}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Pincode"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Landmark
              </label>
              <input
                type="text"
                {...register('location.landmark')}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Near..."
              />
            </div>
          </div>
        </div>

        {/* Property Details */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center">
            <FiGrid className="mr-2" /> Property Details
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Bedrooms *
              </label>
              <input
                type="number"
                {...register('bedrooms', { required: 'Bedrooms count is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                min="0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Bathrooms *
              </label>
              <input
                type="number"
                {...register('bathrooms', { required: 'Bathrooms count is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                min="0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Area (sq.ft) *
              </label>
              <input
                type="number"
                {...register('area', { required: 'Area is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                min="0"
              />
            </div>
          </div>

          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description *
            </label>
            <textarea
              {...register('description', { required: 'Description is required' })}
              rows="4"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
              placeholder="Describe your property..."
            ></textarea>
          </div>
        </div>

        {/* Amenities */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Amenities</h2>
          
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={newAmenity}
              onChange={(e) => setNewAmenity(e.target.value)}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
              placeholder="e.g., Swimming Pool, Gym, Parking"
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addAmenity())}
            />
            <button
              type="button"
              onClick={addAmenity}
              className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
            >
              Add
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            {amenities.map((amenity, index) => (
              <span
                key={index}
                className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100"
              >
                {amenity}
                <button
                  type="button"
                  onClick={() => removeAmenity(index)}
                  className="ml-2 text-gray-500 hover:text-red-500"
                >
                  <FiX size={14} />
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Images */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Property Images</h2>
          
          <div className="mb-4">
            <label className="block w-full p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-primary">
              <div className="text-center">
                <FiUpload className="mx-auto h-8 w-8 text-gray-400" />
                <span className="mt-2 block text-sm text-gray-600">
                  Click to upload images (Max 10, each up to 5MB)
                </span>
              </div>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </label>
          </div>

          {/* Image Previews */}
          {imagePreviews.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {imagePreviews.map((preview, index) => (
                <div key={index} className="relative group">
                  <img
                    src={preview}
                    alt={`Preview ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition"
                  >
                    <FiX size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Submit Buttons */}
        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={() => navigate('/dashboard')}
            className="px-6 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 disabled:opacity-50"
          >
            {loading ? 'Saving...' : (id ? 'Update Property' : 'Add Property')}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddProperty;