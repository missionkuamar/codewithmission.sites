import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProperties } from '../redux/slices/propertySlice';
import { 
  FiSearch, 
  FiMapPin, 
  FiHome, 
  FiTrendingUp,
  FiChevronRight,
  FiStar,
  FiCamera,
  FiUsers,
  FiAward,
  FiClock,
  FiShield,
  FiHeart,
  FiMessageCircle,
  FiArrowRight
} from 'react-icons/fi';
import { BiBath, BiBed, BiArea } from 'react-icons/bi';
import { MdVerified } from 'react-icons/md';

const Home = () => {
  const dispatch = useDispatch();
  const { properties } = useSelector((state) => state.properties);
  const [searchQuery, setSearchQuery] = useState('');
  const [featuredProperties, setFeaturedProperties] = useState([]);

  // Fetch properties on mount
  useEffect(() => {
    dispatch(fetchProperties({ limit: 6, sortBy: 'createdAt', sortOrder: 'desc' }));
  }, [dispatch]);

  // Filter featured properties
  useEffect(() => {
    if (properties?.length) {
      setFeaturedProperties(properties.filter(p => p.featured).slice(0, 6));
    }
  }, [properties]);

  // Stats for the platform
  const stats = [
    { label: 'Properties', value: '2,500+', icon: FiHome },
    { label: 'Happy Clients', value: '1,800+', icon: FiUsers },
    { label: 'Cities', value: '50+', icon: FiMapPin },
    { label: 'Verified Agents', value: '500+', icon: FiShield }
  ];

  // Features list
  const features = [
    {
      icon: FiSearch,
      title: 'Smart Search',
      description: 'Advanced filters to find your dream property quickly',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: FiCamera,
      title: 'Virtual Tours',
      description: '360° virtual tours of properties from anywhere',
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: FiTrendingUp,
      title: 'Price Analytics',
      description: 'Real-time market analysis and price trends',
      color: 'from-green-500 to-green-600'
    },
    {
      icon: FiShield,
      title: 'Verified Listings',
      description: 'All properties are verified by our team',
      color: 'from-orange-500 to-orange-600'
    }
  ];

  // Property types
  const propertyTypes = [
    { name: 'Apartment', icon: FiHome, count: 850, color: 'blue' },
    { name: 'Villa', icon: FiHome, count: 320, color: 'green' },
    { name: 'Plot', icon: FiHome, count: 450, color: 'purple' },
    { name: 'Commercial', icon: FiHome, count: 280, color: 'orange' }
  ];

  // Testimonials
  const testimonials = [
    {
      name: 'Rajesh Kumar',
      role: 'Home Buyer',
      content: 'Found my dream home in just 2 weeks! The platform is amazing and the agents are very helpful.',
      rating: 5,
      image: 'https://randomuser.me/api/portraits/men/1.jpg'
    },
    {
      name: 'Priya Sharma',
      role: 'Property Investor',
      content: 'Best platform for real estate investments. The analytics feature helped me make informed decisions.',
      rating: 5,
      image: 'https://randomuser.me/api/portraits/women/2.jpg'
    },
    {
      name: 'Amit Patel',
      role: 'Seller',
      content: 'Sold my property within a month. Great reach and professional service.',
      rating: 5,
      image: 'https://randomuser.me/api/portraits/men/3.jpg'
    }
  ];

  const formatPrice = (price) => {
    if (price >= 10000000) {
      return `₹${(price / 10000000).toFixed(2)} Cr`;
    } else if (price >= 100000) {
      return `₹${(price / 100000).toFixed(2)} Lac`;
    }
    return `₹${price.toLocaleString()}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white overflow-hidden">
      
      {/* ========== HERO SECTION ========== */}
      <section className="relative bg-gradient-to-r from-primary via-primary/90 to-primary/80 text-white">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: '30px 30px'
          }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="text-center lg:text-left space-y-8">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight animate-fade-in-up">
                Find Your <span className="text-yellow-300">Dream Home</span>
                <br />With Confidence
              </h1>
              
              <p className="text-xl text-white/90 max-w-xl mx-auto lg:mx-0">
                Discover thousands of properties with verified listings, virtual tours, and expert guidance.
              </p>

              {/* Search Bar */}
              <div className="bg-white rounded-2xl p-2 shadow-2xl max-w-2xl mx-auto lg:mx-0">
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="flex-1 relative">
                    <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search by city, location, or property..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-12 pr-4 py-4 rounded-xl text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <Link
                    to={`/properties?search=${searchQuery}`}
                    className="bg-primary hover:bg-primary/90 text-white px-8 py-4 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                  >
                    Search <FiArrowRight />
                  </Link>
                </div>
              </div>

              {/* Quick Links */}
              <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
                <span className="text-white/80">Popular:</span>
                {['Mumbai', 'Delhi', 'Bangalore', 'Pune'].map((city, i) => (
                  <Link
                    key={i}
                    to={`/properties?city=${city}`}
                    className="px-4 py-2 bg-white/20 text-white rounded-full hover:bg-white/30 transition text-sm"
                  >
                    {city}
                  </Link>
                ))}
              </div>
            </div>

            {/* Right Content - Hero Image */}
            <div className="relative hidden lg:block">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                  alt="Luxury Home"
                  className="w-full h-[500px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                
                {/* Floating Stats Card */}
                <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur rounded-xl p-4 shadow-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Starting from</p>
                      <p className="text-xl font-bold text-primary">₹25 Lac</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">Properties</p>
                      <p className="text-xl font-bold text-gray-900">2,500+</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-yellow-400 rounded-full opacity-20 animate-pulse"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-blue-400 rounded-full opacity-20 animate-pulse delay-1000"></div>
            </div>
          </div>
        </div>

        {/* Wave Divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#ffffff" fillOpacity="1" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,170.7C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
          </svg>
        </div>
      </section>

      {/* ========== STATS SECTION ========== */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="bg-primary/5 w-20 h-20 mx-auto rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition">
                  <stat.icon className="h-8 w-8 text-primary" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== FEATURES SECTION ========== */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Us?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We provide the best platform for buying, selling, and renting properties
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition group"
              >
                <div className={`bg-gradient-to-r ${feature.color} w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition`}>
                  <feature.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== PROPERTY TYPES SECTION ========== */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Browse by Property Type
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Find the perfect property type for your needs
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {propertyTypes.map((type, index) => (
              <Link
                key={index}
                to={`/properties?propertyType=${type.name.toLowerCase()}`}
                className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition"
              >
                <div className={`bg-${type.color}-500 h-48 flex flex-col items-center justify-center text-white`}>
                  <type.icon className="h-12 w-12 mb-3 group-hover:scale-110 transition" />
                  <h3 className="text-xl font-bold">{type.name}</h3>
                  <p className="text-sm opacity-90">{type.count} Properties</p>
                </div>
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition"></div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ========== FEATURED PROPERTIES SECTION ========== */}
      {featuredProperties.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-center mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                  Featured Properties
                </h2>
                <p className="text-xl text-gray-600">
                  Hand-picked properties just for you
                </p>
              </div>
              <Link
                to="/properties"
                className="mt-4 md:mt-0 flex items-center gap-2 text-primary hover:text-primary/80 font-semibold"
              >
                View All <FiChevronRight />
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProperties.map((property) => (
                <Link
                  key={property._id}
                  to={`/property/${property._id}`}
                  className="group bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={property.images?.[0]?.url || 'https://via.placeholder.com/400x300'}
                      alt={property.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
                    />
                    <div className="absolute top-3 right-3 bg-yellow-500 text-white px-3 py-1 rounded-lg text-sm flex items-center gap-1">
                      <FiStar className="fill-white" /> Featured
                    </div>
                    {!property.isApproved && (
                      <div className="absolute top-3 left-3 bg-orange-500 text-white px-3 py-1 rounded-lg text-sm">
                        Pending
                      </div>
                    )}
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition">
                      {property.title}
                    </h3>
                    
                    <div className="flex items-center text-gray-600 mb-3">
                      <FiMapPin className="mr-1 flex-shrink-0" />
                      <span className="text-sm truncate">
                        {property.location?.city}, {property.location?.state}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mb-3">
                      <span className="text-2xl font-bold text-primary">
                        {formatPrice(property.price)}
                      </span>
                      <span className={`px-3 py-1 text-xs rounded-full ${
                        property.status === 'sale' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {property.status === 'sale' ? 'For Sale' : 'For Rent'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-sm text-gray-600 border-t pt-3">
                      <div className="flex items-center gap-1">
                        <BiBed className="text-primary" />
                        <span>{property.bedrooms} Beds</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <BiBath className="text-primary" />
                        <span>{property.bathrooms} Baths</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <BiArea className="text-primary" />
                        <span>{property.area} sq.ft</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ========== HOW IT WORKS SECTION ========== */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Three simple steps to your dream property
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Search',
                description: 'Browse thousands of properties with our smart filters',
                icon: FiSearch,
                color: 'blue'
              },
              {
                step: '02',
                title: 'Connect',
                description: 'Contact sellers directly or schedule site visits',
                icon: FiMessageCircle,
                color: 'green'
              },
              {
                step: '03',
                title: 'Own',
                description: 'Complete the deal with our expert guidance',
                icon: FiAward,
                color: 'purple'
              }
            ].map((item, index) => (
              <div key={index} className="relative text-center group">
                <div className={`bg-${item.color}-500 w-20 h-20 mx-auto rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition`}>
                  <item.icon className="h-8 w-8 text-white" />
                </div>
                <div className="absolute -top-4 -right-4 w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-3xl font-bold text-gray-300 opacity-50">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== TESTIMONIALS SECTION ========== */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Our Clients Say
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Real experiences from real people
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <FiStar key={i} className="fill-yellow-500 text-yellow-500" />
                  ))}
                </div>
                <p className="text-gray-700 italic">"{testimonial.content}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== CTA SECTION ========== */}
      <section className="py-16 bg-gradient-to-r from-primary to-primary/90 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Find Your Dream Home?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Join thousands of happy homeowners and investors
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/properties"
              className="bg-white text-primary px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition"
            >
              Browse Properties
            </Link>
            <Link
              to="/register"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white/10 transition"
            >
              Create Account
            </Link>
          </div>
        </div>
      </section>

      {/* Add custom animations */}
      <style jsx>{`
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fade-in-up {
          animation: fade-in-up 0.6s ease-out;
        }
      `}</style>
    </div>
  );
};

export default Home;