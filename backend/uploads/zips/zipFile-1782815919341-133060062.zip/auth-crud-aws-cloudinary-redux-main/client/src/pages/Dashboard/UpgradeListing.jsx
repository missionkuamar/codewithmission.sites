import React from 'react';
import { FiStar, FiTrendingUp, FiCamera, FiCheck } from 'react-icons/fi';

const UpgradeListing = () => {
  const plans = [
    {
      name: 'Basic',
      price: 'Free',
      features: ['3 Properties', 'Basic Stats', 'Email Support']
    },
    {
      name: 'Featured',
      price: '₹999/month',
      features: ['Unlimited Properties', 'Featured Badge', 'Priority Support', 'Analytics', 'Top Search Results']
    },
    {
      name: 'Premium',
      price: '₹1999/month',
      features: ['Everything in Featured', 'Video Tours', 'Virtual Staging', 'Dedicated Agent', 'WhatsApp Integration']
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-6">Upgrade Your Listings</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan, index) => (
          <div key={index} className="border rounded-xl p-6 hover:shadow-xl transition">
            <h3 className="text-lg font-bold mb-2">{plan.name}</h3>
            <p className="text-2xl font-bold text-primary mb-4">{plan.price}</p>
            <ul className="space-y-2 mb-6">
              {plan.features.map((feature, i) => (
                <li key={i} className="flex items-center gap-2 text-sm">
                  <FiCheck className="text-green-500" />
                  {feature}
                </li>
              ))}
            </ul>
            <button className="w-full py-2 bg-primary text-white rounded-lg hover:bg-primary/90">
              Select Plan
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};