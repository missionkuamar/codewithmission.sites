import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import {
  fetchStats,
  fetchUsers,
  fetchPendingProperties,
  updateUserStatus,
  deleteUser,
  approveProperty
} from '../../redux/slices/adminSlice';
import {
  FiUsers,
  FiHome,
  FiClock,
  FiEye,
  FiCheckCircle,
  FiXCircle,
  FiUserCheck,
  FiUserX,
  FiTrash2,
  FiBarChart2,
  FiMapPin,
  FiPackage,
  FiTrendingUp
} from 'react-icons/fi';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
} from 'chart.js';
import { Bar, Pie, Line } from 'react-chartjs-2';
import toast from 'react-hot-toast';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

const AdminDashboard = () => {
  const dispatch = useDispatch();
  const { stats, users, pendingProperties, loading } = useSelector((state) => state.admin);
  const [activeTab, setActiveTab] = useState('overview');
  const [userFilters, setUserFilters] = useState({
    page: 1,
    limit: 10,
    search: '',
    role: ''
  });
  const [rejectionModal, setRejectionModal] = useState({
    show: false,
    propertyId: null,
    reason: ''
  });

  useEffect(() => {
    dispatch(fetchStats());
    dispatch(fetchUsers(userFilters));
    dispatch(fetchPendingProperties());
  }, [dispatch]);

  const handleUserStatus = async (userId, currentStatus) => {
    try {
      await dispatch(updateUserStatus({ userId, isActive: !currentStatus })).unwrap();
      toast.success(`User ${!currentStatus ? 'activated' : 'blocked'} successfully`);
    } catch (error) {
      toast.error(error || 'Failed to update user');
    }
  };

  const handleDeleteUser = async (userId) => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      try {
        await dispatch(deleteUser(userId)).unwrap();
        toast.success('User deleted successfully');
      } catch (error) {
        toast.error(error || 'Failed to delete user');
      }
    }
  };

  const handleApproveProperty = async (propertyId) => {
    try {
      await dispatch(approveProperty({ propertyId, isApproved: true })).unwrap();
      toast.success('Property approved successfully');
    } catch (error) {
      toast.error(error || 'Failed to approve property');
    }
  };

  const handleRejectProperty = async () => {
    if (!rejectionModal.reason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }
    
    try {
      await dispatch(approveProperty({
        propertyId: rejectionModal.propertyId,
        isApproved: false,
        rejectionReason: rejectionModal.reason
      })).unwrap();
      toast.success('Property rejected');
      setRejectionModal({ show: false, propertyId: null, reason: '' });
    } catch (error) {
      toast.error(error || 'Failed to reject property');
    }
  };

  if (loading && !stats) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            {[
              { id: 'overview', label: 'Overview', icon: FiBarChart2 },
              { id: 'users', label: 'Users', icon: FiUsers },
              { id: 'approvals', label: 'Property Approvals', icon: FiClock },
              { id: 'reports', label: 'Reports', icon: FiTrendingUp }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <tab.icon className="h-5 w-5" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Overview Tab */}
        {activeTab === 'overview' && stats && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <FiUsers className="h-6 w-6 text-blue-600" />
                  </div>
                  <span className="text-3xl font-bold">{stats.users.total}</span>
                </div>
                <h3 className="text-gray-600">Total Users</h3>
                <div className="mt-2 flex gap-4 text-sm">
                  <span className="text-green-600">{stats.users.sellers} Sellers</span>
                  <span className="text-blue-600">{stats.users.buyers} Buyers</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <FiHome className="h-6 w-6 text-green-600" />
                  </div>
                  <span className="text-3xl font-bold">{stats.properties.total}</span>
                </div>
                <h3 className="text-gray-600">Total Properties</h3>
                <div className="mt-2 flex gap-4 text-sm">
                  <span className="text-green-600">{stats.properties.approved} Approved</span>
                  <span className="text-yellow-600">{stats.properties.pending} Pending</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-yellow-100 p-3 rounded-lg">
                    <FiClock className="h-6 w-6 text-yellow-600" />
                  </div>
                  <span className="text-3xl font-bold">{stats.properties.pending}</span>
                </div>
                <h3 className="text-gray-600">Pending Approvals</h3>
                <div className="mt-2 text-sm text-gray-500">
                  Need your attention
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-purple-100 p-3 rounded-lg">
                    <FiEye className="h-6 w-6 text-purple-600" />
                  </div>
                  <span className="text-3xl font-bold">{stats.properties.totalViews}</span>
                </div>
                <h3 className="text-gray-600">Total Views</h3>
                <div className="mt-2 text-sm text-gray-500">
                  All time property views
                </div>
              </div>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Properties by Type */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Properties by Type</h3>
                <Pie
                  data={{
                    labels: stats.charts.propertiesByType.map(item => item._id),
                    datasets: [
                      {
                        data: stats.charts.propertiesByType.map(item => item.count),
                        backgroundColor: [
                          '#FF6384',
                          '#36A2EB',
                          '#FFCE56',
                          '#4BC0C0',
                          '#9966FF'
                        ]
                      }
                    ]
                  }}
                  options={{
                    responsive: true,
                    plugins: {
                      legend: {
                        position: 'bottom'
                      }
                    }
                  }}
                />
              </div>

              {/* Properties by City */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Top Cities</h3>
                <Bar
                  data={{
                    labels: stats.charts.propertiesByCity.map(item => item._id),
                    datasets: [
                      {
                        label: 'Properties',
                        data: stats.charts.propertiesByCity.map(item => item.count),
                        backgroundColor: '#3B82F6'
                      }
                    ]
                  }}
                  options={{
                    responsive: true,
                    plugins: {
                      legend: {
                        display: false
                      }
                    }
                  }}
                />
              </div>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Users */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Recent Users</h3>
                <div className="space-y-4">
                  {stats.recent.users.map((user) => (
                    <div key={user._id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-gray-100 rounded-full p-2">
                          <FiUsers className="h-4 w-4 text-gray-600" />
                        </div>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded ${
                        user.role === 'seller' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {user.role}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Properties */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Recent Properties</h3>
                <div className="space-y-4">
                  {stats.recent.properties.map((property) => (
                    <div key={property._id} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{property.title}</p>
                        <p className="text-sm text-gray-500">
                          By {property.sellerId?.name} • ₹{property.price}
                        </p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded ${
                        property.isApproved ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {property.isApproved ? 'Approved' : 'Pending'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 border-b">
              <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <h2 className="text-xl font-semibold">User Management</h2>
                <div className="flex gap-4">
                  <input
                    type="text"
                    placeholder="Search users..."
                    className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    value={userFilters.search}
                    onChange={(e) => setUserFilters({ ...userFilters, search: e.target.value, page: 1 })}
                  />
                  <select
                    className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    value={userFilters.role}
                    onChange={(e) => setUserFilters({ ...userFilters, role: e.target.value, page: 1 })}
                  >
                    <option value="">All Roles</option>
                    <option value="admin">Admin</option>
                    <option value="seller">Seller</option>
                    <option value="buyer">Buyer</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Joined</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {users.map((user) => (
                    <tr key={user._id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                          <p className="text-sm text-gray-500">{user.phone}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-xs rounded ${
                          user.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                          user.role === 'seller' ? 'bg-green-100 text-green-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-xs rounded ${
                          user.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {user.isActive ? 'Active' : 'Blocked'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => handleUserStatus(user._id, user.isActive)}
                            className={`p-2 rounded-md ${
                              user.isActive 
                                ? 'text-yellow-600 hover:bg-yellow-50' 
                                : 'text-green-600 hover:bg-green-50'
                            }`}
                            title={user.isActive ? 'Block User' : 'Activate User'}
                          >
                            {user.isActive ? <FiUserX /> : <FiUserCheck />}
                          </button>
                          {user.role !== 'admin' && (
                            <button
                              onClick={() => handleDeleteUser(user._id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-md"
                              title="Delete User"
                            >
                              <FiTrash2 />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Property Approvals Tab */}
        {activeTab === 'approvals' && (
          <div className="space-y-6">
            {pendingProperties.length === 0 ? (
              <div className="bg-white rounded-xl shadow-lg p-12 text-center">
                <FiCheckCircle className="mx-auto h-12 w-12 text-green-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">No Pending Approvals</h3>
                <p className="text-gray-500 mt-2">All properties have been reviewed.</p>
              </div>
            ) : (
              pendingProperties.map((property) => (
                <div key={property._id} className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6">
                    <div className="flex flex-col md:flex-row justify-between gap-6">
                      {/* Property Image */}
                      <div className="md:w-48">
                        <img
                          src={property.images?.[0]?.url || 'https://via.placeholder.com/200'}
                          alt={property.title}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                      </div>

                      {/* Property Details */}
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold mb-2">{property.title}</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                          <div>
                            <p className="text-sm text-gray-500">Price</p>
                            <p className="font-medium">₹{property.price.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Type</p>
                            <p className="font-medium capitalize">{property.propertyType}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Location</p>
                            <p className="font-medium">{property.location?.city}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Seller</p>
                            <p className="font-medium">{property.sellerId?.name}</p>
                          </div>
                        </div>
                        <p className="text-gray-600 text-sm line-clamp-2">{property.description}</p>
                      </div>

                      {/* Actions */}
                      <div className="flex md:flex-col gap-2 justify-end">
                        <Link
                          to={`/property/${property._id}`}
                          target="_blank"
                          className="px-4 py-2 text-primary border border-primary rounded-lg hover:bg-primary/5"
                        >
                          View
                        </Link>
                        <button
                          onClick={() => handleApproveProperty(property._id)}
                          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => setRejectionModal({
                            show: true,
                            propertyId: property._id,
                            reason: ''
                          })}
                          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Reports Tab */}
        {activeTab === 'reports' && stats && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-4">Monthly Property Listings</h3>
              <Line
                data={{
                  labels: stats.charts.monthlyStats.map(item => item._id),
                  datasets: [
                    {
                      label: 'Properties Added',
                      data: stats.charts.monthlyStats.map(item => item.count),
                      borderColor: '#3B82F6',
                      backgroundColor: 'rgba(59, 130, 246, 0.1)',
                      tension: 0.4
                    }
                  ]
                }}
                options={{
                  responsive: true,
                  plugins: {
                    legend: {
                      display: false
                    }
                  }
                }}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold mb-4">User Growth</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Total Users</span>
                    <span className="font-bold">{stats.users.total}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Sellers</span>
                    <span className="font-bold">{stats.users.sellers}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Buyers</span>
                    <span className="font-bold">{stats.users.buyers}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Admin</span>
                    <span className="font-bold">
                      {stats.users.total - stats.users.sellers - stats.users.buyers}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Property Statistics</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Total Properties</span>
                    <span className="font-bold">{stats.properties.total}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Approved</span>
                    <span className="font-bold text-green-600">{stats.properties.approved}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Pending</span>
                    <span className="font-bold text-yellow-600">{stats.properties.pending}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Total Views</span>
                    <span className="font-bold">{stats.properties.totalViews}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Rejection Modal */}
      {rejectionModal.show && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold mb-4">Reject Property</h3>
            <p className="text-gray-600 mb-4">Please provide a reason for rejection:</p>
            <textarea
              value={rejectionModal.reason}
              onChange={(e) => setRejectionModal({ ...rejectionModal, reason: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg mb-4"
              rows="4"
              placeholder="e.g., Incomplete information, inappropriate content..."
            ></textarea>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setRejectionModal({ show: false, propertyId: null, reason: '' })}
                className="px-4 py-2 border rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleRejectProperty}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Reject Property
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;