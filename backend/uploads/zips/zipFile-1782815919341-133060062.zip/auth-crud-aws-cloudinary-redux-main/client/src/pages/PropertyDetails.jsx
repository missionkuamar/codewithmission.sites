import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, Link } from 'react-router-dom';
import { fetchPropertyById } from '../redux/slices/propertySlice';
import { 
  FiMapPin, FiHome, FiMaximize, FiDollarSign, FiUser, 
  FiPhone, FiMail, FiCalendar, FiGrid, FiCamera, 
  FiHeart, FiShare2, FiChevronLeft, FiChevronRight,
  FiCheckCircle, FiXCircle, FiWifi, FiCoffee,
  FiSun, FiLock, FiWind, FiTv, FiThermometer, FiAward,
  FiMessageCircle, FiStar
} from 'react-icons/fi';
import { FaCar } from "react-icons/fa";
import { BiBath, BiBed, BiArea } from 'react-icons/bi';
import { MdBalcony, MdSecurity, MdPool, MdFitnessCenter } from 'react-icons/md';
import { GiElevator, GiWaterTank, GiGasPump } from 'react-icons/gi';
import toast from 'react-hot-toast';
import { GiHomeGarage } from "react-icons/gi";
const PropertyDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { currentProperty: property, loading } = useSelector((state) => state.properties);
  const { user } = useSelector((state) => state.auth);

  // States
  const [selectedImage, setSelectedImage] = useState(0);
  const [showAllAmenities, setShowAllAmenities] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [contactForm, setContactForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    message: `I'm interested in ${property?.title}. Please contact me.`
  });
  const [activeTab, setActiveTab] = useState('description'); // description, amenities, location
  const [showLightbox, setShowLightbox] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  useEffect(() => {
    dispatch(fetchPropertyById(id));
    window.scrollTo(0, 0);
  }, [dispatch, id]);

  // Format price
  const formatPrice = (price) => {
    if (price >= 10000000) {
      return `₹${(price / 10000000).toFixed(2)} Cr`;
    } else if (price >= 100000) {
      return `₹${(price / 100000).toFixed(2)} Lac`;
    }
    return `₹${price.toLocaleString()}`;
  };

  // Format date
  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Handle contact submit
  const handleContactSubmit = (e) => {
    e.preventDefault();
    toast.success('Inquiry sent successfully! Seller will contact you soon.');
    setContactForm({ ...contactForm, message: '' });
  };

  // Handle share
  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Link copied to clipboard!');
  };

  // Handle lightbox navigation
  const nextImage = () => {
    setLightboxIndex((prev) => 
      prev === property.images.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    setLightboxIndex((prev) => 
      prev === 0 ? property.images.length - 1 : prev - 1
    );
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="relative">
          <div className="animate-spin rounded-full h-20 w-20 border-4 border-primary border-t-transparent"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <FiHome className="h-8 w-8 text-primary animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  // Not found state
  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🏠</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Property Not Found</h2>
          <p className="text-gray-600 mb-6">The property you're looking for doesn't exist or has been removed.</p>
          <Link to="/properties" className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition">
            Browse Properties
          </Link>
        </div>
      </div>
    );
  }

  const images = property.images || [];
  const amenities = property.amenities || [];

  // Amenity icons mapping
  const getAmenityIcon = (amenity) => {
    const amenityLower = amenity.toLowerCase();
    if (amenityLower.includes('wifi') || amenityLower.includes('internet')) return <FiWifi />;
    if (amenityLower.includes('parking')) return <GiHomeGarage />;
    if (amenityLower.includes('security')) return <MdSecurity />;
    if (amenityLower.includes('pool') || amenityLower.includes('swimming')) return <MdPool />;
    if (amenityLower.includes('gym') || amenityLower.includes('fitness')) return <MdFitnessCenter />;
    if (amenityLower.includes('elevator') || amenityLower.includes('lift')) return <GiElevator />;
    if (amenityLower.includes('ac') || amenityLower.includes('air')) return <FiWind />;
    if (amenityLower.includes('tv') || amenityLower.includes('cable')) return <FiTv />;
    if (amenityLower.includes('balcony')) return <MdBalcony />;
    if (amenityLower.includes('water')) return <GiWaterTank />;
    if (amenityLower.includes('gas')) return <GiGasPump />;
    if (amenityLower.includes('heater')) return <FiThermometer />;
    return <FiCheckCircle />; // default icon
  };

  return (
    <div className="bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section with Image Gallery */}
      <div className="relative">
        {/* Main Image */}
        <div className="relative h-[60vh] lg:h-[70vh] overflow-hidden">
          <img
            src={images[selectedImage]?.url || 'https://via.placeholder.com/1600x900'}
            alt={property.title}
            className="w-full h-full object-cover"
          />
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
          
          {/* Action Buttons */}
          <div className="absolute top-6 right-6 flex gap-3">
            <button
              onClick={() => setIsLiked(!isLiked)}
              className="bg-white/90 backdrop-blur p-3 rounded-full hover:bg-white transition shadow-lg"
            >
              <FiHeart className={`h-5 w-5 ${isLiked ? 'fill-red-500 text-red-500' : 'text-gray-700'}`} />
            </button>
            <button
              onClick={handleShare}
              className="bg-white/90 backdrop-blur p-3 rounded-full hover:bg-white transition shadow-lg"
            >
              <FiShare2 className="h-5 w-5 text-gray-700" />
            </button>
          </div>
          
          {/* Image Counter */}
          <div className="absolute bottom-6 left-6 bg-black/50 backdrop-blur text-white px-4 py-2 rounded-full text-sm flex items-center gap-2">
            <FiCamera className="h-4 w-4" />
            <span>{selectedImage + 1} / {images.length}</span>
          </div>
          
          {/* Navigation Arrows */}
          {images.length > 1 && (
            <>
              <button
                onClick={() => setSelectedImage(prev => prev === 0 ? images.length - 1 : prev - 1)}
                className="absolute left-6 top-1/2 transform -translate-y-1/2 bg-white/90 backdrop-blur p-3 rounded-full hover:bg-white transition shadow-lg"
              >
                <FiChevronLeft className="h-5 w-5" />
              </button>
              <button
                onClick={() => setSelectedImage(prev => prev === images.length - 1 ? 0 : prev + 1)}
                className="absolute right-6 top-1/2 transform -translate-y-1/2 bg-white/90 backdrop-blur p-3 rounded-full hover:bg-white transition shadow-lg"
              >
                <FiChevronRight className="h-5 w-5" />
              </button>
            </>
          )}
        </div>
        
        {/* Thumbnail Strip */}
        {images.length > 1 && (
          <div className="container mx-auto px-4 -mt-20 relative z-10">
            <div className="bg-white rounded-2xl shadow-xl p-4">
              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-300">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`flex-shrink-0 transition-all duration-300 ${
                      selectedImage === index 
                        ? 'ring-4 ring-primary scale-105 z-10' 
                        : 'opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={image.url}
                      alt={`Thumbnail ${index + 1}`}
                      className="w-24 h-20 object-cover rounded-lg"
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - 2/3 width */}
          <div className="lg:col-span-2 space-y-8">
            {/* Property Header */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <div className="flex flex-wrap justify-between items-start gap-4 mb-6">
                <div>
                  <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                    {property.title}
                  </h1>
                  <div className="flex items-center text-gray-600">
                    <FiMapPin className="mr-2 flex-shrink-0 text-primary" />
                    <span className="text-lg">
                      {property.location?.address}, {property.location?.city}, {property.location?.state} - {property.location?.pincode}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-4xl font-bold text-primary mb-2">
                    {formatPrice(property.price)}
                  </div>
                  <span className={`inline-block px-4 py-2 rounded-full text-sm font-semibold ${
                    property.status === 'sale' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-blue-100 text-blue-800'
                  }`}>
                    {property.status === 'sale' ? 'For Sale' : 'For Rent'}
                  </span>
                </div>
              </div>

              {/* Key Features Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl p-4 text-center">
                  <BiBed className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="font-bold text-xl">{property.bedrooms}</div>
                  <div className="text-sm text-gray-600">Bedrooms</div>
                </div>
                <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl p-4 text-center">
                  <BiBath className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="font-bold text-xl">{property.bathrooms}</div>
                  <div className="text-sm text-gray-600">Bathrooms</div>
                </div>
                <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl p-4 text-center">
                  <BiArea className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="font-bold text-xl">{property.area}</div>
                  <div className="text-sm text-gray-600">Sq.Ft</div>
                </div>
                <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl p-4 text-center">
                  <FiHome className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="font-bold text-xl capitalize">{property.propertyType}</div>
                  <div className="text-sm text-gray-600">Type</div>
                </div>
              </div>
            </div>

            {/* Tabs Navigation */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="flex border-b">
                {['description', 'amenities', 'location'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex-1 py-4 px-6 text-sm font-medium capitalize transition-all relative ${
                      activeTab === tab
                        ? 'text-primary'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    {tab}
                    {activeTab === tab && (
                      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"></div>
                    )}
                  </button>
                ))}
              </div>

              <div className="p-8">
                {/* Description Tab */}
                {activeTab === 'description' && (
                  <div>
                    <h3 className="text-xl font-semibold mb-4">About This Property</h3>
                    <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                      {property.description}
                    </p>
                  </div>
                )}

                {/* Amenities Tab */}
                {activeTab === 'amenities' && (
                  <div>
                    <h3 className="text-xl font-semibold mb-4">Amenities & Features</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {amenities.map((amenity, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-primary/5 transition"
                        >
                          <span className="text-primary text-xl">
                            {getAmenityIcon(amenity)}
                          </span>
                          <span className="text-gray-700">{amenity}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Location Tab */}
                {activeTab === 'location' && (
                  <div>
                    <h3 className="text-xl font-semibold mb-4">Location Details</h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <FiMapPin className="text-primary mt-1" />
                        <div>
                          <p className="font-medium">Address</p>
                          <p className="text-gray-600">
                            {property.location?.address}, {property.location?.landmark && `${property.location.landmark}, `}
                            {property.location?.city}, {property.location?.state} - {property.location?.pincode}
                          </p>
                        </div>
                      </div>
                      
                      {/* Map Placeholder */}
                      <div className="mt-4 bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                        <p className="text-gray-500">📍 Map integration coming soon</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column - 1/3 width */}
          <div className="lg:col-span-1 space-y-6">
            {/* Seller Card */}
            <div className="bg-gradient-to-br from-primary to-primary/80 text-white rounded-2xl shadow-lg p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="bg-white/20 p-4 rounded-full">
                  <FiUser className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Property Owner</h3>
                  <p className="text-white/90">{property.sellerId?.name}</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <a
                  href={`tel:${property.sellerId?.phone}`}
                  className="flex items-center gap-3 text-white/90 hover:text-white transition p-3 bg-white/10 rounded-lg"
                >
                  <FiPhone className="h-5 w-5" />
                  <span>{property.sellerId?.phone}</span>
                </a>
                
                <a
                  href={`mailto:${property.sellerId?.email}`}
                  className="flex items-center gap-3 text-white/90 hover:text-white transition p-3 bg-white/10 rounded-lg"
                >
                  <FiMail className="h-5 w-5" />
                  <span>{property.sellerId?.email}</span>
                </a>
                
                <div className="flex items-center gap-3 text-white/90 p-3 bg-white/10 rounded-lg">
                  <FiCalendar className="h-5 w-5" />
                  <span>Member since {new Date(property.sellerId?.createdAt).getFullYear()}</span>
                </div>
              </div>

              {user?._id === property.sellerId?._id && (
                <Link
                  to={`/edit-property/${property._id}`}
                  className="mt-6 block w-full text-center py-3 bg-white text-primary rounded-lg font-semibold hover:bg-white/90 transition"
                >
                  Edit Property
                </Link>
              )}
            </div>

            {/* Contact Form */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <FiMessageCircle className="text-primary" />
                Interested?
              </h3>
              
              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Your Name"
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                    required
                  />
                </div>
                
                <div>
                  <input
                    type="email"
                    placeholder="Email Address"
                    value={contactForm.email}
                    onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                    required
                  />
                </div>
                
                <div>
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    value={contactForm.phone}
                    onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                    required
                  />
                </div>
                
                <div>
                  <textarea
                    placeholder="Message"
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    rows="4"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition resize-none"
                    required
                  />
                </div>
                
                <button
                  type="submit"
                  className="w-full py-4 bg-primary text-white rounded-lg font-semibold hover:bg-primary/90 transition transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  Send Inquiry
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox Modal */}
      {showLightbox && (
        <div className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center">
          <button
            onClick={() => setShowLightbox(false)}
            className="absolute top-6 right-6 text-white/70 hover:text-white text-4xl"
          >
            ×
          </button>
          
          <button
            onClick={prevImage}
            className="absolute left-6 top-1/2 transform -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white p-4 rounded-full"
          >
            <FiChevronLeft className="h-6 w-6" />
          </button>
          
          <img
            src={images[lightboxIndex]?.url}
            alt=""
            className="max-h-[90vh] max-w-[90vw] object-contain"
          />
          
          <button
            onClick={nextImage}
            className="absolute right-6 top-1/2 transform -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white p-4 rounded-full"
          >
            <FiChevronRight className="h-6 w-6" />
          </button>
          
          <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 text-white bg-black/50 px-4 py-2 rounded-full">
            {lightboxIndex + 1} / {images.length}
          </div>
        </div>
      )}
    </div>
  );
};

export default PropertyDetails;