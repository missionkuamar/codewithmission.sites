import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchOverview,
  fetchViewsAnalytics,
  fetchPropertyPerformance,
  fetchLeadAnalytics,
  fetchMarketComparison,
  setPeriod
} from '../../redux/slices/analyticsSlice';
import {
  FiEye,
  FiMessageCircle,
  FiHome,
  FiStar,
  FiTrendingUp,
  FiDownload,
  FiCalendar,
  FiBarChart2,
  FiUsers,
  FiAward,
  FiArrowUp,
  FiArrowDown
} from 'react-icons/fi';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  PointElement,
  LineElement,
  Filler
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';
import toast from 'react-hot-toast';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  PointElement,
  LineElement,
  Filler
);

const SellerAnalytics = () => {
  const dispatch = useDispatch();
  const { overview, viewsData, properties, leads, comparison, period, loading } = 
    useSelector((state) => state.analytics);
  const [timeRange, setTimeRange] = useState('monthly');

  useEffect(() => {
    // Fetch all analytics data
    dispatch(fetchOverview());
    dispatch(fetchViewsAnalytics(timeRange));
    dispatch(fetchPropertyPerformance());
    dispatch(fetchLeadAnalytics());
    dispatch(fetchMarketComparison());
  }, [dispatch, timeRange]);

  const handlePeriodChange = (newPeriod) => {
    setTimeRange(newPeriod);
    dispatch(setPeriod(newPeriod));
    dispatch(fetchViewsAnalytics(newPeriod));
  };

  const exportReport = () => {
    // Create CSV
    const headers = ['Property', 'Views', 'Inquiries', 'Conversion Rate', 'Status'];
    const data = properties.map(p => [
      p.title,
      p.views,
      p.inquiries,
      `${p.conversionRate}%`,
      p.status
    ]);

    const csv = [headers, ...data].map(row => row.join(',')).join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    
    toast.success('Report downloaded successfully');
  };

  if (loading && !overview) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
          <p className="text-gray-600">Track your property performance</p>
        </div>
        <div className="flex gap-3 mt-4 md:mt-0">
          <select
            value={timeRange}
            onChange={(e) => handlePeriodChange(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
          <button
            onClick={exportReport}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90"
          >
            <FiDownload />
            Export Report
          </button>
        </div>
      </div>

      {/* Overview Cards */}
      {overview && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <FiEye className="h-6 w-6 text-blue-600" />
              </div>
              <span className="text-2xl font-bold">{overview.overview.totalViews}</span>
            </div>
            <h3 className="text-gray-600">Total Views</h3>
            <p className="text-sm text-gray-500 mt-1">
              Avg {overview.overview.avgViews} per property
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <FiMessageCircle className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-2xl font-bold">{overview.overview.totalInquiries}</span>
            </div>
            <h3 className="text-gray-600">Total Inquiries</h3>
            <p className="text-sm text-gray-500 mt-1">
              {overview.overview.uniqueInquirers} unique contacts
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <FiHome className="h-6 w-6 text-purple-600" />
              </div>
              <span className="text-2xl font-bold">{overview.overview.totalProperties}</span>
            </div>
            <h3 className="text-gray-600">Properties</h3>
            <p className="text-sm text-gray-500 mt-1">
              {overview.overview.featuredCount} featured
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-yellow-100 p-3 rounded-lg">
                <FiTrendingUp className="h-6 w-6 text-yellow-600" />
              </div>
              <span className="text-2xl font-bold">
                {overview.overview.mostViewed?.views || 0}
              </span>
            </div>
            <h3 className="text-gray-600">Top Performance</h3>
            <p className="text-sm text-gray-500 mt-1 truncate">
              {overview.overview.mostViewed?.title || 'N/A'}
            </p>
          </div>
        </div>
      )}

      {/* Views Chart */}
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h2 className="text-lg font-semibold mb-4">Views Over Time</h2>
        {viewsData && viewsData.length > 0 ? (
          <Line
            data={{
              labels: viewsData.map(d => d._id),
              datasets: [
                {
                  label: 'Views',
                  data: viewsData.map(d => d.views),
                  borderColor: '#3B82F6',
                  backgroundColor: 'rgba(59, 130, 246, 0.1)',
                  tension: 0.4,
                  fill: true
                }
              ]
            }}
            options={{
              responsive: true,
              plugins: {
                legend: {
                  display: false
                }
              }
            }}
          />
        ) : (
          <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
            <p className="text-gray-400">No view data available</p>
          </div>
        )}
      </div>

      {/* Market Comparison */}
      {comparison && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h2 className="text-lg font-semibold mb-4">Price Comparison</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Your Average</span>
                <span className="font-bold text-lg">₹{comparison.price.seller.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Market Average</span>
                <span className="font-bold">₹{comparison.price.market.toLocaleString()}</span>
              </div>
              <div className={`flex justify-between items-center pt-2 border-t ${
                comparison.price.percentDiff > 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                <span className="flex items-center gap-1">
                  {comparison.price.percentDiff > 0 ? <FiArrowUp /> : <FiArrowDown />}
                  Difference
                </span>
                <span className="font-bold">
                  {comparison.price.percentDiff > 0 ? '+' : ''}
                  {comparison.price.percentDiff}%
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h2 className="text-lg font-semibold mb-4">Views Comparison</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Your Average Views</span>
                <span className="font-bold text-lg">{comparison.views.seller}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Market Average</span>
                <span className="font-bold">{comparison.views.market}</span>
              </div>
              <div className={`flex justify-between items-center pt-2 border-t ${
                comparison.views.percentDiff > 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                <span className="flex items-center gap-1">
                  {comparison.views.percentDiff > 0 ? <FiArrowUp /> : <FiArrowDown />}
                  Performance
                </span>
                <span className="font-bold">
                  {comparison.views.percentDiff > 0 ? '+' : ''}
                  {comparison.views.percentDiff}%
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Property Performance Table */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="p-6 border-b">
          <h2 className="text-lg font-semibold">Property Performance</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Property
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Views
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Inquiries
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Conversion
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Score
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {properties && properties.length > 0 ? (
                properties.map((property) => (
                  <tr key={property.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium">{property.title}</p>
                        <p className="text-sm text-gray-500">{property.location}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-medium">{property.views}</td>
                    <td className="px-6 py-4">{property.inquiries}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs rounded ${
                        property.conversionRate > 5 
                          ? 'bg-green-100 text-green-800'
                          : property.conversionRate > 2
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {property.conversionRate}%
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs rounded ${
                        property.status === 'sale' 
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-purple-100 text-purple-800'
                      }`}>
                        {property.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-primary rounded-full h-2"
                            style={{ width: `${property.score}%` }}
                          ></div>
                        </div>
                        <span className="text-sm">{property.score}</span>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="px-6 py-8 text-center text-gray-500">
                    No property data available
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Lead Analytics */}
      {leads && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg">
            <h2 className="text-lg font-semibold mb-4">Recent Leads</h2>
            <div className="space-y-4">
              {leads.recent && leads.recent.length > 0 ? (
                leads.recent.map((lead) => (
                  <div key={lead.id} className="flex items-center justify-between border-b pb-3">
                    <div>
                      <p className="font-medium">{lead.name}</p>
                      <p className="text-sm text-gray-500">{lead.property}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm">{lead.phone}</p>
                      <p className="text-xs text-gray-400">
                        {new Date(lead.date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">No leads yet</p>
              )}
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h2 className="text-lg font-semibold mb-4">Lead Statistics</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Total Leads</span>
                <span className="font-bold text-xl">{leads.total}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Contacted</span>
                <span className="font-bold">{leads.contacted}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Converted</span>
                <span className="font-bold">{leads.converted}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t">
                <span className="text-gray-600">Conversion Rate</span>
                <span className="font-bold text-green-600">{leads.conversionRate}%</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SellerAnalytics;