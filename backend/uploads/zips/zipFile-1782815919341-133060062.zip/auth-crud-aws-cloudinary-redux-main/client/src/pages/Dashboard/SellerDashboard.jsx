import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { fetchMyProperties, deleteProperty } from '../../redux/slices/propertySlice';
import { 
  FiEdit2, FiTrash2, FiEye, FiPlusCircle, FiStar,
  FiTrendingUp, FiMessageCircle, FiDollarSign
} from 'react-icons/fi';
import SellerAnalytics from './SellerAnalytics';

import toast from 'react-hot-toast';

const SellerDashboard = () => {
  const dispatch = useDispatch();
  const { myProperties, loading } = useSelector((state) => state.properties);
  const { user } = useSelector((state) => state.auth);
  const [activeTab, setActiveTab] = useState('properties');

  useEffect(() => {
    dispatch(fetchMyProperties());
  }, [dispatch]);

  // Calculate stats
  const totalViews = myProperties.reduce((sum, p) => sum + (p.views || 0), 0);
  const featuredCount = myProperties.filter(p => p.featured).length;
  const pendingApprovals = myProperties.filter(p => !p.isApproved).length;

  return (
    <div className="max-w-7xl mx-auto py-8 px-4">
      {/* Header with Upgrade Button */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold">Welcome, {user?.name}!</h1>
          <p className="text-gray-600">Manage your properties and grow your business</p>
        </div>
        <div className="flex gap-3 mt-4 md:mt-0">
          <Link
            to="/add-property"
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90"
          >
            <FiPlusCircle />
            Add Property
          </Link>
          <Link
            to="/upgrade"
            className="flex items-center gap-2 px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600"
          >
            <FiStar />
            Upgrade
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Total Properties</p>
              <p className="text-2xl font-bold mt-2">{myProperties.length}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <FiEye className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Total Views</p>
              <p className="text-2xl font-bold mt-2">{totalViews}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <FiTrendingUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Featured</p>
              <p className="text-2xl font-bold mt-2">{featuredCount}</p>
            </div>
            <div className="bg-yellow-100 p-3 rounded-lg">
              <FiStar className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Inquiries</p>
              <p className="text-2xl font-bold mt-2">12</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <FiMessageCircle className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b mb-6">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('properties')}
            className={`pb-4 px-1 ${
              activeTab === 'properties'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500'
            }`}
          >
            My Properties
          </button>
          <button
            onClick={() => setActiveTab('inquiries')}
            className={`pb-4 px-1 ${
              activeTab === 'inquiries'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500'
            }`}
          >
            Inquiries
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`pb-4 px-1 ${
              activeTab === 'analytics'
                ? 'border-b-2 border-primary text-primary'
                : 'text-gray-500'
            }`}
          >
            Analytics
          </button>
          <button
  onClick={() => setActiveTab('analytics')}
  className={`pb-4 px-1 ${
    activeTab === 'analytics'
      ? 'border-b-2 border-primary text-primary'
      : 'text-gray-500'
  }`}
>
  Analytics
</button>
        </nav>
      </div>

      {/* Properties Tab */}
      {activeTab === 'properties' && (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left">Property</th>
                <th className="px-6 py-3 text-left">Price</th>
                <th className="px-6 py-3 text-left">Status</th>
                <th className="px-6 py-3 text-left">Views</th>
                <th className="px-6 py-3 text-left">Approval</th>
                <th className="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {myProperties.map((property) => (
                <tr key={property._id}>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <img
                        src={property.images?.[0]?.url || '/placeholder.jpg'}
                        className="w-12 h-12 object-cover rounded mr-3"
                      />
                      <div>
                        <p className="font-medium">{property.title}</p>
                        <p className="text-sm text-gray-500">{property.location?.city}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">₹{property.price.toLocaleString()}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs rounded ${
                      property.status === 'sale' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {property.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">{property.views || 0}</td>
                  <td className="px-6 py-4">
                    {property.isApproved ? (
                      <span className="text-green-600">✅ Approved</span>
                    ) : (
                      <span className="text-yellow-600">⏳ Pending</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <Link to={`/property/${property._id}`} className="p-2 hover:bg-gray-100 rounded">
                        <FiEye />
                      </Link>
                      <Link to={`/edit-property/${property._id}`} className="p-2 hover:bg-gray-100 rounded">
                        <FiEdit2 />
                      </Link>
                      <button className="p-2 hover:bg-red-100 text-red-600 rounded">
                        <FiTrash2 />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Inquiries Tab */}
      {activeTab === 'inquiries' && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Inquiries</h3>
          <p className="text-gray-500">No inquiries yet</p>
        </div>
      )}


{activeTab === 'analytics' && <SellerAnalytics />}


      {/* Analytics Tab */}
      {activeTab === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Views Over Time</h3>
            <div className="h-64 flex items-center justify-center border-2 border-dashed rounded">
              <p className="text-gray-400">Chart coming soon</p>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Top Performing Properties</h3>
            <div className="space-y-3">
              {myProperties.slice(0, 3).map((p, i) => (
                <div key={p._id} className="flex justify-between items-center">
                  <span className="text-sm">{p.title}</span>
                  <span className="font-semibold">{p.views || 0} views</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};