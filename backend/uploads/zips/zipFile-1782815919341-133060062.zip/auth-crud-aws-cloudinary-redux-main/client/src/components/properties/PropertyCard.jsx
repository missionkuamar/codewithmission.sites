import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { FiMapPin, FiMaximize, FiHome, FiDollarSign, FiEdit2, FiTrash2 } from 'react-icons/fi';
import { deleteProperty } from '../../redux/slices/propertySlice';
import toast from 'react-hot-toast';

const PropertyCard = ({ property }) => {
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);
  
  const formatPrice = (price) => {
    if (price >= 10000000) {
      return `₹${(price / 10000000).toFixed(2)} Cr`;
    } else if (price >= 100000) {
      return `₹${(price / 100000).toFixed(2)} Lac`;
    }
    return `₹${price.toLocaleString()}`;
  };

  // Check if current user is the seller
  const isSeller = user?._id === property.sellerId?._id;

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this property?')) {
      try {
        await dispatch(deleteProperty(property._id)).unwrap();
        toast.success('Property deleted successfully');
      } catch (error) {
        toast.error(error || 'Failed to delete property');
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition relative">
      {/* Image */}
      <Link to={`/property/${property._id}`}>
        <div className="relative h-48">
          <img
            src={property.images?.[0]?.url || 'https://via.placeholder.com/400x300'}
            alt={property.title}
            className="w-full h-full object-cover"
          />
          {property.featured && (
            <span className="absolute top-2 left-2 bg-yellow-500 text-white px-2 py-1 text-xs rounded">
              Featured
            </span>
          )}
          <span className="absolute top-2 right-2 bg-primary text-white px-2 py-1 text-xs rounded">
            {property.status === 'sale' ? 'For Sale' : 'For Rent'}
          </span>
        </div>
      </Link>

      {/* Content */}
      <div className="p-4">
        <Link to={`/property/${property._id}`}>
          <h3 className="text-lg font-semibold text-gray-800 mb-1 truncate">
            {property.title}
          </h3>
        </Link>
        
        <div className="flex items-center text-gray-600 text-sm mb-2">
          <FiMapPin className="mr-1 flex-shrink-0" />
          <span className="truncate">
            {property.location?.address}, {property.location?.city}
          </span>
        </div>

        <div className="flex items-center justify-between mb-3">
          <span className="text-2xl font-bold text-primary">
            {formatPrice(property.price)}
          </span>
        </div>

        <div className="flex items-center gap-4 text-sm text-gray-600 border-t pt-3">
          <div className="flex items-center">
            <FiHome className="mr-1" />
            <span>{property.bedrooms} BHK</span>
          </div>
          <div className="flex items-center">
            <FiMaximize className="mr-1" />
            <span>{property.area} sq.ft</span>
          </div>
          <div className="flex items-center">
            <span>{property.propertyType}</span>
          </div>
        </div>

        {/* Edit/Delete Buttons */}
        {isSeller && (
          <div className="flex justify-end gap-2 mt-3 pt-3 border-t">
            <Link
              to={`/edit-property/${property._id}`}
              className="p-2 text-blue-600 hover:bg-blue-50 rounded-md transition"
              title="Edit Property"
            >
              <FiEdit2 />
            </Link>
            <button
              onClick={handleDelete}
              className="p-2 text-red-600 hover:bg-red-50 rounded-md transition"
              title="Delete Property"
            >
              <FiTrash2 />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PropertyCard;