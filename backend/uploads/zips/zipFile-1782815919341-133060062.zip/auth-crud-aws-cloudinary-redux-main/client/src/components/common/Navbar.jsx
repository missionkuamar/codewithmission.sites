import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout, loadUser } from '../../redux/slices/authSlice.js';
import { 
  FiHome, FiLogOut, FiUser, FiPlusCircle, 
  FiUsers, FiSettings, FiBarChart2, FiShield 
} from 'react-icons/fi';

const Navbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useSelector((state) => state.auth);

  useEffect(() => {
    if (localStorage.getItem('token')) {
      dispatch(loadUser());
    }
  }, [dispatch]);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
  };

  // Debug: Check user role
  console.log('Current user:', user);
  console.log('Is admin?', user?.role === 'admin');

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="bg-primary/10 p-2 rounded-lg group-hover:bg-primary/20 transition">
                <FiHome className="h-6 w-6 text-primary" />
              </div>
              <span className="font-bold text-xl text-gray-800">RealEstate</span>
            </Link>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center space-x-2">
            {/* Public Links */}
            <Link 
              to="/properties" 
              className="text-gray-700 hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition"
            >
              Properties
            </Link>

            {isAuthenticated ? (
              <>
                {/* Seller Specific Link */}
                {user?.role === 'seller' && (
                  <Link 
                    to="/add-property" 
                    className="flex items-center space-x-1 text-gray-700 hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition"
                  >
                    <FiPlusCircle className="h-4 w-4" />
                    <span>Add Property</span>
                  </Link>
                )}

                {/* 👑 ADMIN SPECIFIC LINK - Yeh add kiya hai */}
                {user?.role === 'admin' && (
                  <>
                    <Link 
                      to="/admin" 
                      className="flex items-center space-x-1 bg-purple-100 text-purple-700 hover:bg-purple-200 px-4 py-2 rounded-md text-sm font-medium transition"
                    >
                      <FiShield className="h-4 w-4" />
                      <span>Admin</span>
                    </Link>
                    
                    <Link 
                      to="/admin?tab=users" 
                      className="flex items-center space-x-1 text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition"
                      title="Manage Users"
                    >
                      <FiUsers className="h-4 w-4" />
                    </Link>
                    
                    <Link 
                      to="/admin?tab=approvals" 
                      className="flex items-center space-x-1 text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md text-sm font-medium transition"
                      title="Property Approvals"
                    >
                      <FiBarChart2 className="h-4 w-4" />
                    </Link>
                  </>
                )}

                {/* User Dashboard Link */}
                <Link 
                  to={user?.role === 'admin' ? '/admin' : '/dashboard'} 
                  className="flex items-center space-x-1 text-gray-700 hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition"
                >
                  <div className="bg-gray-100 rounded-full p-1">
                    <FiUser className="h-4 w-4" />
                  </div>
                  <span className="hidden sm:inline">{user?.name?.split(' ')[0]}</span>
                  {user?.role === 'admin' && (
                    <span className="ml-1 text-xs bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded-full">
                      Admin
                    </span>
                  )}
                </Link>

                {/* Logout Button */}
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-1 text-gray-700 hover:text-red-600 px-3 py-2 rounded-md text-sm font-medium transition"
                >
                  <FiLogOut className="h-4 w-4" />
                  <span className="hidden sm:inline">Logout</span>
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="text-gray-700 hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition"
                >
                  Login
                </Link>
                <Link 
                  to="/register" 
                  className="bg-primary text-white hover:bg-primary/90 px-4 py-2 rounded-md text-sm font-medium transition"
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Admin Quick Access Bar (Optional) */}
      {isAuthenticated && user?.role === 'admin' && (
        <div className="bg-purple-50 border-t border-purple-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center space-x-6 py-2 text-sm">
              <span className="text-purple-700 font-medium flex items-center">
                <FiShield className="mr-1" /> Admin Panel:
              </span>
              <Link to="/admin" className="text-purple-600 hover:text-purple-800">
                Dashboard
              </Link>
              <Link to="/admin?tab=users" className="text-purple-600 hover:text-purple-800">
                Users
              </Link>
              <Link to="/admin?tab=approvals" className="text-purple-600 hover:text-purple-800">
                Approvals
              </Link>
              <Link to="/admin?tab=reports" className="text-purple-600 hover:text-purple-800">
                Reports
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;