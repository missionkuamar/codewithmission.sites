import api from './api';

const adminService = {
  // Dashboard stats
  async getStats() {
    try {
      const response = await api.get('/admin/stats');
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // User management
  async getUsers(params = {}) {
    try {
      const queryString = new URLSearchParams(params).toString();
      const response = await api.get(`/admin/users?${queryString}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  async updateUserStatus(userId, isActive) {
    try {
      const response = await api.put(`/admin/users/${userId}/status`, { isActive });
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  async deleteUser(userId) {
    try {
      const response = await api.delete(`/admin/users/${userId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Property approval
  async getPendingProperties() {
    try {
      const response = await api.get('/admin/properties/pending');
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  async approveProperty(propertyId, isApproved, rejectionReason = '') {
    try {
      const response = await api.put(`/admin/properties/${propertyId}/approve`, {
        isApproved,
        rejectionReason
      });
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  }
};

export default adminService;