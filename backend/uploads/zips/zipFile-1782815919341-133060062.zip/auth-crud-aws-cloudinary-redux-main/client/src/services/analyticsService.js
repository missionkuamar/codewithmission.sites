import api from './api';

const analyticsService = {
  async getOverview() {
    try {
      const response = await api.get('/analytics/overview');
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  async getViewsAnalytics(period = 'monthly') {
    try {
      const response = await api.get(`/analytics/views?period=${period}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  async getPropertyPerformance() {
    try {
      const response = await api.get('/analytics/properties');
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  async getLeadAnalytics() {
    try {
      const response = await api.get('/analytics/leads');
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  async getMarketComparison() {
    try {
      const response = await api.get('/analytics/comparison');
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  async trackView(propertyId) {
    try {
      const response = await api.post(`/analytics/track-view/${propertyId}`);
      return response.data;
    } catch (error) {
      console.error('Track view error:', error);
    }
  }
};

export default analyticsService;