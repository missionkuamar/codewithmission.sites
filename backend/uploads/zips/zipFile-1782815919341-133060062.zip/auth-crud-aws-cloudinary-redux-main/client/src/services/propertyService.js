import api from './api';

// ✅ Property service object banaya
const propertyService = {
  // Get all properties with filters
  async getProperties(params = {}) {
    try {
      const queryString = new URLSearchParams(params).toString();
      const response = await api.get(`/properties?${queryString}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Get single property
  async getPropertyById(id) {
    try {
      const response = await api.get(`/properties/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Get seller's properties
  async getMyProperties() {
    try {
      const response = await api.get('/properties/seller/me');
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Create property
  async createProperty(formData) {
    try {
      const response = await api.post('/properties', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Update property
// Update property
async updateProperty(id, formData) {
  try {
    console.log('PropertyService: Updating property', id);
    
    // Log FormData contents
    for (let pair of formData.entries()) {
      console.log('FormData entry:', pair[0], pair[1]);
    }
    
    const response = await api.put(`/properties/${id}`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    
    console.log('PropertyService: Update response', response.data);
    return response.data;
  } catch (error) {
    console.error('PropertyService: Update error', error);
    throw error.response?.data || error.message;
  }
},

  // Delete property
  async deleteProperty(id) {
    try {
      const response = await api.delete(`/properties/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Delete property image
  async deleteImage(propertyId, imageId) {
    try {
      const response = await api.delete(`/properties/${propertyId}/images/${imageId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  }
};

// ✅ Yeh line important hai - default export
export default propertyService;